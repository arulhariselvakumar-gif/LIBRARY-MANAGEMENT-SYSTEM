# Library Management System (DSA Minor Project)

Python + Tkinter + SQLite desktop application. Works offline, no paid services, no extra packages.

## 1. Requirements
- Windows 10/11, Python 3.9 or newer from https://www.python.org (tick "Add Python to PATH" while installing)
- Visual Studio Code (optional, but recommended)
- Tkinter and SQLite are included with the standard Python installer

## 2. Run the application
Open the `library_management` folder in VS Code, open a terminal (Ctrl + `) and run:

```
python main.py
```

Default login:  **username `admin`   password `admin123`**

The first run creates `library.db` with sample books and students. Your data stays saved when you close the app.
To start fresh, close the app and delete `library.db`.

## 3. Run the tests
```
python -m unittest discover -s tests -t . -v
```
Tests use temporary databases, so they never touch your real `library.db`.

## 4. Where each DSA concept is used
| Concept | File | Used for |
|---|---|---|
| Linked list | `dsa/linked_list.py` | Borrowing history of a book (`IssueReturnManager.get_book_history`) |
| Stack | `dsa/stack.py` | Recent activity + Undo last issue/return (`IssueReturnManager.activity`) |
| Queue | `dsa/queue.py` | Reservation waiting list, served first-come-first-served on return |
| Binary Search Tree | `dsa/binary_search_tree.py` | Title index for prefix search (`SearchSortService._search_title`) |
| Linear search | `dsa/searching.py` | Author / Category search, and title search when the BST finds nothing |
| Binary search | `dsa/searching.py` | Book ID search on a list sorted by merge sort |
| Merge sort | `dsa/sorting.py` | Main sorting by title / author / available quantity |
| Bubble sort | `dsa/sorting.py` | Selectable on the Search & Sort screen, shows comparisons and swaps |
| Python lists | everywhere | Holding records loaded from SQLite |

SQLite stores the data. The DSA classes work on the in-memory records, so the academic part stays separate.

## 5. Complexity summary
| Algorithm | Best | Average | Worst | Space |
|---|---|---|---|---|
| Linear search | O(n)* | O(n) | O(n) | O(1) extra |
| Binary search | O(1) | O(log n) | O(log n) | O(1) |
| BST insert/search | O(log n) | O(log n) | O(n) | O(n) |
| Bubble sort | O(n) | O(n^2) | O(n^2) | O(1) |
| Merge sort | O(n log n) | O(n log n) | O(n log n) | O(n) |
| Stack push/pop, Queue enqueue/dequeue | O(1) | O(1) | O(1) | O(n) |

*Our linear search scans every record because many records can match.

## 6. Settings you may change
`main.py` top: `LOAN_DAYS = 14` and `FINE_PER_DAY = 2`.

## 7. Folder structure
```
library_management/
    main.py  database.py  auth.py  book_manager.py  student_manager.py
    issue_return.py  search_sort.py  reports.py  requirements.txt  README.md
    dsa/    linked_list.py stack.py queue.py binary_search_tree.py searching.py sorting.py
    ui/     login.py dashboard.py books.py students.py transactions.py reservations.py
            search.py reports.py widgets.py
    tests/  test_dsa.py test_library.py
```
(`reports.py` at top level and `ui/widgets.py` are small extra files added to keep the code clean.)

## 8. Known limitations
- Single admin user; no multi-user roles.
- Undo works only for the most recent issue/return, and not after a copy was auto-issued from the queue.
- The title BST is rebuilt on every title search (fine for a college-sized library).
