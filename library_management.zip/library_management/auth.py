"""Password hashing and admin login (hashlib.pbkdf2_hmac + random salt)."""
import hashlib
import hmac
import os

from database import get_connection

ITERATIONS = 100_000


def hash_password(password, salt_hex=None):
    """Return (hash_hex, salt_hex). A new random salt is made when none is given."""
    salt = bytes.fromhex(salt_hex) if salt_hex else os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return digest.hex(), salt.hex()


def verify_password(password, stored_hash, salt_hex):
    new_hash, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(new_hash, stored_hash)


class AuthError(Exception):
    """Raised for empty or wrong login details."""


def login(username, password, db_path=None):
    """Return the username if the login is valid, otherwise raise AuthError."""
    username = (username or "").strip()
    if not username or not password:
        raise AuthError("Please enter both username and password.")
    conn = get_connection(db_path)
    try:
        row = conn.execute(
            "SELECT username, password_hash, salt FROM users WHERE username = ?",
            (username,),
        ).fetchone()
    finally:
        conn.close()
    if row is None or not verify_password(password, row["password_hash"], row["salt"]):
        raise AuthError("Invalid username or password.")
    return row["username"]
