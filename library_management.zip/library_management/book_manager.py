"""Add / view / update / delete books."""
import sqlite3

from database import get_connection, log_activity


class BookManager:
    def __init__(self, db_path=None):
        self.db_path = db_path

    # ---------- validation ----------
    @staticmethod
    def _clean(title, author, category, isbn, quantity):
        title, author = (title or "").strip(), (author or "").strip()
        category, isbn = (category or "").strip(), (isbn or "").strip()
        if not (title and author and category and isbn):
            raise ValueError("Title, author, category and ISBN are required.")
        try:
            quantity = int(quantity)
        except (TypeError, ValueError):
            raise ValueError("Quantity must be a whole number.")
        if quantity < 0:
            raise ValueError("Quantity cannot be negative.")
        return title, author, category, isbn, quantity

    # ---------- operations ----------
    def add_book(self, title, author, category, isbn, quantity):
        title, author, category, isbn, quantity = self._clean(title, author, category, isbn, quantity)
        conn = get_connection(self.db_path)
        try:
            with conn:
                cur = conn.execute(
                    "INSERT INTO books (title, author, category, isbn, quantity, available_copies) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (title, author, category, isbn, quantity, quantity),
                )
                log_activity(conn, "ADD_BOOK", f"Added book '{title}' (ID {cur.lastrowid})")
                return cur.lastrowid
        except sqlite3.IntegrityError:
            raise ValueError(f"A book with ISBN {isbn} already exists.")
        finally:
            conn.close()

    def get_all_books(self):
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute("SELECT * FROM books ORDER BY book_id").fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def get_book(self, book_id):
        conn = get_connection(self.db_path)
        try:
            row = conn.execute("SELECT * FROM books WHERE book_id = ?", (book_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def update_book(self, book_id, title, author, category, isbn, quantity):
        """Change details. available_copies moves by the same amount as quantity."""
        title, author, category, isbn, quantity = self._clean(title, author, category, isbn, quantity)
        conn = get_connection(self.db_path)
        try:
            with conn:
                row = conn.execute("SELECT quantity, available_copies FROM books WHERE book_id = ?",
                                   (book_id,)).fetchone()
                if row is None:
                    raise ValueError("Book not found.")
                new_available = row["available_copies"] + (quantity - row["quantity"])
                if new_available < 0:
                    issued = row["quantity"] - row["available_copies"]
                    raise ValueError(f"Quantity cannot be below the {issued} copies currently issued.")
                conn.execute(
                    "UPDATE books SET title=?, author=?, category=?, isbn=?, quantity=?, "
                    "available_copies=? WHERE book_id=?",
                    (title, author, category, isbn, quantity, new_available, book_id),
                )
                log_activity(conn, "UPDATE_BOOK", f"Updated book ID {book_id}")
        except sqlite3.IntegrityError:
            raise ValueError(f"Another book already uses ISBN {isbn}.")
        finally:
            conn.close()

    def delete_book(self, book_id):
        """Delete only if the book has never been issued or reserved."""
        conn = get_connection(self.db_path)
        try:
            with conn:
                if conn.execute("SELECT 1 FROM books WHERE book_id = ?", (book_id,)).fetchone() is None:
                    raise ValueError("Book not found.")
                used = conn.execute("SELECT 1 FROM book_issues WHERE book_id = ? LIMIT 1", (book_id,)).fetchone()
                reserved = conn.execute("SELECT 1 FROM reservations WHERE book_id = ? LIMIT 1", (book_id,)).fetchone()
                if used or reserved:
                    raise ValueError("This book has issue/reservation history, so it cannot be deleted.")
                conn.execute("DELETE FROM books WHERE book_id = ?", (book_id,))
                log_activity(conn, "DELETE_BOOK", f"Deleted book ID {book_id}")
        finally:
            conn.close()
