"""SQLite connection, schema creation and sample data."""
import os
import sqlite3
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "library.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    salt          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
    book_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title            TEXT NOT NULL,
    author           TEXT NOT NULL,
    category         TEXT NOT NULL,
    isbn             TEXT NOT NULL UNIQUE,
    quantity         INTEGER NOT NULL CHECK (quantity >= 0),
    available_copies INTEGER NOT NULL CHECK (available_copies >= 0),
    CHECK (available_copies <= quantity)
);

CREATE TABLE IF NOT EXISTS students (
    student_id INTEGER PRIMARY KEY AUTOINCREMENT,
    reg_no     TEXT NOT NULL UNIQUE,
    name       TEXT NOT NULL,
    department TEXT,
    email      TEXT,
    phone      TEXT
);

CREATE TABLE IF NOT EXISTS book_issues (
    issue_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id     INTEGER NOT NULL REFERENCES books(book_id),
    student_id  INTEGER NOT NULL REFERENCES students(student_id),
    issue_date  TEXT NOT NULL,
    due_date    TEXT NOT NULL,
    return_date TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_active_issue
    ON book_issues(book_id, student_id) WHERE return_date IS NULL;

CREATE TABLE IF NOT EXISTS reservations (
    reservation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id        INTEGER NOT NULL REFERENCES books(book_id),
    student_id     INTEGER NOT NULL REFERENCES students(student_id),
    reserved_on    TEXT NOT NULL,
    status         TEXT NOT NULL DEFAULT 'WAITING'
                   CHECK (status IN ('WAITING', 'FULFILLED', 'CANCELLED'))
);

CREATE TABLE IF NOT EXISTS activity_logs (
    log_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    action     TEXT NOT NULL,
    details    TEXT,
    created_at TEXT NOT NULL
);
"""

SAMPLE_BOOKS = [
    ("Data Structures Using Python", "Reema Thareja", "Computer Science", "9780190000001", 5),
    ("Introduction to Algorithms", "Thomas Cormen", "Computer Science", "9780262033848", 3),
    ("Python Crash Course", "Eric Matthes", "Programming", "9781593279288", 4),
    ("Database System Concepts", "Abraham Silberschatz", "Databases", "9780078022159", 2),
    ("Artificial Intelligence: A Modern Approach", "Stuart Russell", "Artificial Intelligence", "9780134610993", 3),
    ("Hands-On Machine Learning", "Aurelien Geron", "Machine Learning", "9781492032649", 2),
    ("Discrete Mathematics", "Kenneth Rosen", "Mathematics", "9780073383095", 4),
    ("Operating System Concepts", "Abraham Silberschatz", "Computer Science", "9781119800361", 1),
]

SAMPLE_STUDENTS = [
    ("AD2024001", "Arun Kumar", "AI & Data Science", "arun@example.com", "9000000001"),
    ("AD2024002", "Priya Sharma", "AI & Data Science", "priya@example.com", "9000000002"),
    ("AD2024003", "Karthik Raja", "Computer Science", "karthik@example.com", "9000000003"),
    ("AD2024004", "Meena Devi", "Information Technology", "meena@example.com", "9000000004"),
]


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def get_connection(db_path=None):
    """Open a connection with foreign keys ON and rows accessible by column name."""
    conn = sqlite3.connect(db_path or DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def log_activity(conn, action, details=""):
    """Write one row to activity_logs (uses the caller's connection/transaction)."""
    conn.execute(
        "INSERT INTO activity_logs (action, details, created_at) VALUES (?, ?, ?)",
        (action, details, now_str()),
    )


def init_db(db_path=None, with_sample_data=True):
    """Create tables, the default admin user and (optionally) sample data.

    Safe to call every time the app starts: nothing is duplicated.
    Default login -> username: admin   password: admin123
    """
    from auth import hash_password   # imported here to avoid a circular import

    conn = get_connection(db_path)
    try:
        conn.executescript(SCHEMA)
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            pw_hash, salt = hash_password("admin123")
            conn.execute(
                "INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)",
                ("admin", pw_hash, salt),
            )
        if with_sample_data:
            if conn.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0:
                conn.executemany(
                    "INSERT INTO books (title, author, category, isbn, quantity, available_copies) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    [(t, a, c, i, q, q) for t, a, c, i, q in SAMPLE_BOOKS],
                )
            if conn.execute("SELECT COUNT(*) FROM students").fetchone()[0] == 0:
                conn.executemany(
                    "INSERT INTO students (reg_no, name, department, email, phone) "
                    "VALUES (?, ?, ?, ?, ?)",
                    SAMPLE_STUDENTS,
                )
        conn.commit()
    finally:
        conn.close()
