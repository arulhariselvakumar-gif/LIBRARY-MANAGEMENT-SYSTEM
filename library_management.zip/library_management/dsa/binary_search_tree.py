"""Binary Search Tree (BST).

Used in the project as an in-memory INDEX of books by title (lower-case).
Several books can share a title, so every node keeps a list of values.
Insert and traversal are written iteratively to avoid recursion limits.
"""


class BSTNode:
    def __init__(self, key, value):
        self.key = key
        self.values = [value]
        self.left = None
        self.right = None


class BinarySearchTree:
    def __init__(self):
        self.root = None
        self._count = 0           # number of values stored

    def insert(self, key, value):
        """Insert value under key. Average O(log n), worst O(n)."""
        self._count += 1
        if self.root is None:
            self.root = BSTNode(key, value)
            return
        cur = self.root
        while True:
            if key == cur.key:
                cur.values.append(value)
                return
            if key < cur.key:
                if cur.left is None:
                    cur.left = BSTNode(key, value)
                    return
                cur = cur.left
            else:
                if cur.right is None:
                    cur.right = BSTNode(key, value)
                    return
                cur = cur.right

    def search(self, key):
        """Return the list of values stored under exactly this key ([] if none)."""
        cur = self.root
        while cur is not None:
            if key == cur.key:
                return list(cur.values)
            cur = cur.left if key < cur.key else cur.right
        return []

    def prefix_search(self, prefix):
        """Return all values whose key starts with `prefix`, in key order.

        Subtrees that cannot contain a match are skipped, so this is
        faster than scanning every node when the tree is reasonably balanced.
        """
        n = len(prefix)
        found = []
        stack = [self.root]
        while stack:
            node = stack.pop()
            if node is None:
                continue
            head = node.key[:n]
            if head == prefix:
                found.append((node.key, node.values))
            if head >= prefix:
                stack.append(node.left)
            if head <= prefix:
                stack.append(node.right)
        found.sort(key=lambda pair: pair[0])
        result = []
        for _, values in found:
            result.extend(values)
        return result

    def inorder(self):
        """Return all values in ascending key order. O(n)."""
        result, stack, cur = [], [], self.root
        while stack or cur is not None:
            while cur is not None:
                stack.append(cur)
                cur = cur.left
            cur = stack.pop()
            result.extend(cur.values)
            cur = cur.right
        return result

    def height(self):
        """Number of levels in the tree (0 for an empty tree)."""
        if self.root is None:
            return 0
        level, h = [self.root], 0
        while level:
            h += 1
            nxt = []
            for node in level:
                if node.left:
                    nxt.append(node.left)
                if node.right:
                    nxt.append(node.right)
            level = nxt
        return h

    def size(self):
        return self._count

    def is_empty(self):
        return self.root is None
