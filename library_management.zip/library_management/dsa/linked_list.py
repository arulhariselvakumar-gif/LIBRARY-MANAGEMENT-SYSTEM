"""Singly linked list.

Used in the project for the BORROWING HISTORY of a book:
every issue/return record becomes one node, in the order it happened.
"""


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class SinglyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self._size = 0

    def append(self, data):
        """Add a node at the end. O(1) because we keep a tail pointer."""
        node = Node(data)
        if self.head is None:
            self.head = self.tail = node
        else:
            self.tail.next = node
            self.tail = node
        self._size += 1

    def prepend(self, data):
        """Add a node at the beginning. O(1)."""
        node = Node(data)
        node.next = self.head
        self.head = node
        if self.tail is None:
            self.tail = node
        self._size += 1

    def remove(self, data):
        """Remove the first node holding `data`. Returns True if removed. O(n)."""
        prev, cur = None, self.head
        while cur is not None:
            if cur.data == data:
                if prev is None:
                    self.head = cur.next
                else:
                    prev.next = cur.next
                if cur is self.tail:
                    self.tail = prev
                self._size -= 1
                return True
            prev, cur = cur, cur.next
        return False

    def find(self, predicate):
        """Return the first data item for which predicate(item) is True, else None. O(n)."""
        cur = self.head
        while cur is not None:
            if predicate(cur.data):
                return cur.data
            cur = cur.next
        return None

    def to_list(self):
        """Return all items as a normal Python list (head to tail). O(n)."""
        items = []
        cur = self.head
        while cur is not None:
            items.append(cur.data)
            cur = cur.next
        return items

    def is_empty(self):
        return self._size == 0

    def __len__(self):
        return self._size

    def __iter__(self):
        cur = self.head
        while cur is not None:
            yield cur.data
            cur = cur.next
