"""Queue (FIFO), built on linked nodes so enqueue and dequeue are both O(1).

Used in the project for the BOOK RESERVATION WAITING LIST:
the student who reserved first is served first.
"""


class EmptyQueueError(Exception):
    """Raised when dequeue/peek is attempted on an empty queue."""


class _QNode:
    def __init__(self, data):
        self.data = data
        self.next = None


class Queue:
    def __init__(self):
        self._front = None
        self._rear = None
        self._size = 0

    def enqueue(self, item):
        """Add item at the rear. O(1)."""
        node = _QNode(item)
        if self._rear is None:
            self._front = self._rear = node
        else:
            self._rear.next = node
            self._rear = node
        self._size += 1

    def dequeue(self):
        """Remove and return the front item. O(1)."""
        if self._front is None:
            raise EmptyQueueError("Queue is empty")
        node = self._front
        self._front = node.next
        if self._front is None:
            self._rear = None
        self._size -= 1
        return node.data

    def peek(self):
        """Return the front item without removing it. O(1)."""
        if self._front is None:
            raise EmptyQueueError("Queue is empty")
        return self._front.data

    def is_empty(self):
        return self._size == 0

    def size(self):
        return self._size

    def to_list(self):
        """Items from front to rear."""
        items, cur = [], self._front
        while cur is not None:
            items.append(cur.data)
            cur = cur.next
        return items

    def __len__(self):
        return self._size
