"""Searching algorithms written from scratch.

Both functions work on a list of dictionaries (database rows) and a field name.
They also return the number of comparisons so the UI can show the work done.
"""


def linear_search(records, field, value, exact=False):
    """Check every record one by one.

    Works on UNSORTED data.
    Time: O(n) in best, average and worst case (we scan all records
    because several records can match).  Space: O(k) for the k matches.
    Returns (matches, comparisons).
    """
    matches = []
    comparisons = 0
    needle = str(value).strip().lower()
    for rec in records:
        comparisons += 1
        text = str(rec[field]).lower()
        if (text == needle) if exact else (needle in text):
            matches.append(rec)
    return matches, comparisons


def binary_search(sorted_records, field, target):
    """Repeatedly halve a list that is SORTED by `field` (unique values).

    Time: best O(1), average and worst O(log n).  Space: O(1).
    Returns (index or -1, comparisons).
    """
    low, high = 0, len(sorted_records) - 1
    comparisons = 0
    while low <= high:
        mid = (low + high) // 2
        comparisons += 1
        mid_value = sorted_records[mid][field]
        if mid_value == target:
            return mid, comparisons
        if mid_value < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1, comparisons
