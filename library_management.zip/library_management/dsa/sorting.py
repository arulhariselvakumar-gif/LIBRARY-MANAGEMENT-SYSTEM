"""Sorting algorithms written from scratch (no list.sort / sorted()).

`key` is a function that picks the value to sort by, e.g. lambda b: b["title"].
Every function returns a NEW list and leaves the input untouched.
"""


def _identity(x):
    return x


def bubble_sort(items, key=None, reverse=False):
    """Bubble sort. Time: best O(n) (already sorted), average/worst O(n^2). Space O(1) extra."""
    return bubble_sort_counted(items, key, reverse)[0]


def bubble_sort_counted(items, key=None, reverse=False):
    """Bubble sort that also reports (sorted_list, comparisons, swaps)."""
    key = key or _identity
    data = list(items)
    n = len(data)
    comparisons = swaps = 0
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            comparisons += 1
            a, b = key(data[j]), key(data[j + 1])
            out_of_order = (a < b) if reverse else (a > b)
            if out_of_order:
                data[j], data[j + 1] = data[j + 1], data[j]
                swaps += 1
                swapped = True
        if not swapped:          # no swaps in a full pass -> already sorted
            break
    return data, comparisons, swaps


def merge_sort(items, key=None, reverse=False):
    """Merge sort. Time: O(n log n) in best, average and worst case. Space O(n). Stable."""
    key = key or _identity
    data = list(items)
    if len(data) <= 1:
        return data
    mid = len(data) // 2
    left = merge_sort(data[:mid], key, reverse)
    right = merge_sort(data[mid:], key, reverse)
    return _merge(left, right, key, reverse)


def _merge(left, right, key, reverse):
    merged = []
    i = j = 0
    while i < len(left) and j < len(right):
        a, b = key(left[i]), key(right[j])
        take_left = (a >= b) if reverse else (a <= b)   # <= keeps the sort stable
        if take_left:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged
