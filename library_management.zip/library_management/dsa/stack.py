"""Stack (LIFO), built on a Python list.

Used in the project for RECENT ACTIVITY and UNDO of the last issue/return:
the most recent action is always on top.
"""


class EmptyStackError(Exception):
    """Raised when pop/peek is attempted on an empty stack."""


class Stack:
    def __init__(self):
        self._items = []

    def push(self, item):
        """Put item on top. O(1)."""
        self._items.append(item)

    def pop(self):
        """Remove and return the top item. O(1)."""
        if not self._items:
            raise EmptyStackError("Stack is empty")
        return self._items.pop()

    def peek(self):
        """Return the top item without removing it. O(1)."""
        if not self._items:
            raise EmptyStackError("Stack is empty")
        return self._items[-1]

    def is_empty(self):
        return len(self._items) == 0

    def size(self):
        return len(self._items)

    def to_list(self):
        """Items from top (newest) to bottom (oldest)."""
        return list(reversed(self._items))

    def __len__(self):
        return len(self._items)
