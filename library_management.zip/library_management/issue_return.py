"""Issue, return, overdue tracking, reservations and undo.

DSA used here (all genuinely called by the methods below):
  * Stack        -> self.activity: recent actions + undo of the last issue/return
  * Queue        -> reservation waiting list (first reserved, first served)
  * Linked list  -> borrowing history of one book
"""
import sqlite3
from datetime import date, datetime, timedelta

from database import get_connection, log_activity
from dsa.stack import Stack
from dsa.queue import Queue
from dsa.linked_list import SinglyLinkedList

DATE_FMT = "%Y-%m-%d"


def _to_date(value):
    if value is None:
        return date.today()
    if isinstance(value, datetime):
        return value.date()
    return value


class IssueReturnManager:
    def __init__(self, db_path=None, loan_days=14, fine_per_day=2):
        self.db_path = db_path
        self.loan_days = loan_days
        self.fine_per_day = fine_per_day
        self.activity = Stack()      # each item: {"text": str, "undo": tuple or None}

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def overdue_days(due_date_str, today=None):
        today = _to_date(today)
        due = datetime.strptime(due_date_str, DATE_FMT).date()
        return max((today - due).days, 0)

    def fine_for(self, days_overdue):
        return days_overdue * self.fine_per_day

    # ------------------------------------------------------------------ issue
    def issue_book(self, book_id, student_id, today=None):
        """Issue one copy. Returns the new issue_id. One transaction: all or nothing."""
        today = _to_date(today)
        due = today + timedelta(days=self.loan_days)
        conn = get_connection(self.db_path)
        try:
            with conn:
                book = conn.execute("SELECT title, available_copies FROM books WHERE book_id = ?",
                                    (book_id,)).fetchone()
                student = conn.execute("SELECT name FROM students WHERE student_id = ?",
                                       (student_id,)).fetchone()
                if book is None:
                    raise ValueError("Book not found.")
                if student is None:
                    raise ValueError("Student is not registered.")
                if book["available_copies"] <= 0:
                    raise ValueError("No copies available. You can add the student to the reservation queue.")
                try:
                    cur = conn.execute(
                        "INSERT INTO book_issues (book_id, student_id, issue_date, due_date) VALUES (?, ?, ?, ?)",
                        (book_id, student_id, today.strftime(DATE_FMT), due.strftime(DATE_FMT)),
                    )
                except sqlite3.IntegrityError:
                    raise ValueError("This student already has this book issued.")
                conn.execute("UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?",
                             (book_id,))
                text = f"Issued '{book['title']}' to {student['name']}"
                log_activity(conn, "ISSUE", text)
                issue_id = cur.lastrowid
        finally:
            conn.close()
        self.activity.push({"text": text, "undo": ("ISSUE", issue_id)})
        return issue_id

    # ------------------------------------------------------------------ return
    def return_book(self, issue_id, today=None):
        """Return a book. If someone is waiting, the copy goes straight to the first in the queue.

        Returns a dict: overdue_days, fine, auto_issued_to (student name or None).
        """
        today = _to_date(today)
        conn = get_connection(self.db_path)
        auto_name = None
        try:
            with conn:
                row = conn.execute(
                    "SELECT i.book_id, i.due_date, i.return_date, b.title, s.name "
                    "FROM book_issues i JOIN books b ON b.book_id = i.book_id "
                    "JOIN students s ON s.student_id = i.student_id WHERE i.issue_id = ?",
                    (issue_id,),
                ).fetchone()
                if row is None:
                    raise ValueError("Issue record not found.")
                if row["return_date"] is not None:
                    raise ValueError("This book has already been returned.")
                days = self.overdue_days(row["due_date"], today)
                fine = self.fine_for(days)
                conn.execute("UPDATE book_issues SET return_date = ? WHERE issue_id = ?",
                             (today.strftime(DATE_FMT), issue_id))
                conn.execute("UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?",
                             (row["book_id"],))
                text = f"{row['name']} returned '{row['title']}'"
                if days:
                    text += f" ({days} day(s) late, fine {fine})"
                log_activity(conn, "RETURN", text)
                auto_name = self._serve_queue(conn, row["book_id"], row["title"], today)
        finally:
            conn.close()
        self.activity.push({"text": text,
                            "undo": None if auto_name else ("RETURN", issue_id)})
        if auto_name:
            self.activity.push({"text": f"Reserved copy of '{row['title']}' issued to {auto_name}",
                                "undo": None})
        return {"overdue_days": days, "fine": fine, "auto_issued_to": auto_name}

    def _serve_queue(self, conn, book_id, title, today):
        """Load the waiting list into a Queue and serve the FIRST valid student."""
        waiting = Queue()
        for r in conn.execute(
                "SELECT reservation_id, student_id FROM reservations "
                "WHERE book_id = ? AND status = 'WAITING' ORDER BY reservation_id", (book_id,)):
            waiting.enqueue((r["reservation_id"], r["student_id"]))
        while not waiting.is_empty():
            reservation_id, student_id = waiting.dequeue()
            already = conn.execute(
                "SELECT 1 FROM book_issues WHERE book_id = ? AND student_id = ? AND return_date IS NULL",
                (book_id, student_id)).fetchone()
            if already:
                conn.execute("UPDATE reservations SET status = 'CANCELLED' WHERE reservation_id = ?",
                             (reservation_id,))
                continue
            due = today + timedelta(days=self.loan_days)
            conn.execute(
                "INSERT INTO book_issues (book_id, student_id, issue_date, due_date) VALUES (?, ?, ?, ?)",
                (book_id, student_id, today.strftime(DATE_FMT), due.strftime(DATE_FMT)))
            conn.execute("UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?",
                         (book_id,))
            conn.execute("UPDATE reservations SET status = 'FULFILLED' WHERE reservation_id = ?",
                         (reservation_id,))
            name = conn.execute("SELECT name FROM students WHERE student_id = ?",
                                (student_id,)).fetchone()["name"]
            log_activity(conn, "RESERVATION_SERVED", f"'{title}' issued to {name} from the waiting list")
            return name
        return None

    # ------------------------------------------------------------------ undo
    def undo_last(self):
        """Undo the most recent issue or return (top of the stack)."""
        if self.activity.is_empty():
            raise ValueError("Nothing to undo.")
        top = self.activity.peek()
        if top["undo"] is None:
            raise ValueError("The last action cannot be undone.")
        self.activity.pop()
        kind, issue_id = top["undo"]
        conn = get_connection(self.db_path)
        try:
            with conn:
                row = conn.execute("SELECT book_id, return_date FROM book_issues WHERE issue_id = ?",
                                   (issue_id,)).fetchone()
                if row is None:
                    raise ValueError("The record to undo no longer exists.")
                if kind == "ISSUE":
                    if row["return_date"] is not None:
                        raise ValueError("That book was already returned, so the issue cannot be undone.")
                    conn.execute("DELETE FROM book_issues WHERE issue_id = ?", (issue_id,))
                    conn.execute("UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?",
                                 (row["book_id"],))
                else:  # RETURN
                    avail = conn.execute("SELECT available_copies FROM books WHERE book_id = ?",
                                         (row["book_id"],)).fetchone()["available_copies"]
                    if avail <= 0:
                        raise ValueError("The copy has already been given to someone else.")
                    try:
                        conn.execute("UPDATE book_issues SET return_date = NULL WHERE issue_id = ?", (issue_id,))
                    except sqlite3.IntegrityError:
                        raise ValueError("The student has already borrowed this book again.")
                    conn.execute("UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?",
                                 (row["book_id"],))
                log_activity(conn, "UNDO", f"Undid {kind} (issue ID {issue_id})")
        finally:
            conn.close()
        return f"Undid the last {kind.lower()}."

    def recent_activity(self):
        """Recent actions from this session, newest first (read from the stack)."""
        return [item["text"] for item in self.activity.to_list()]

    def activity_log(self, limit=20):
        """Latest rows of the permanent activity_logs table."""
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute("SELECT created_at, action, details FROM activity_logs "
                                "ORDER BY log_id DESC LIMIT ?", (limit,)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    # ------------------------------------------------------------------ queries
    def get_active_issues(self, today=None):
        today = _to_date(today)
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                "SELECT i.issue_id, i.book_id, b.title, i.student_id, s.name AS student_name, "
                "s.reg_no, i.issue_date, i.due_date FROM book_issues i "
                "JOIN books b ON b.book_id = i.book_id JOIN students s ON s.student_id = i.student_id "
                "WHERE i.return_date IS NULL ORDER BY i.issue_id").fetchall()
        finally:
            conn.close()
        result = []
        for r in rows:
            d = dict(r)
            d["overdue_days"] = self.overdue_days(d["due_date"], today)
            d["fine"] = self.fine_for(d["overdue_days"])
            result.append(d)
        return result

    def get_overdue(self, today=None):
        return [r for r in self.get_active_issues(today) if r["overdue_days"] > 0]

    def get_book_history(self, book_id):
        """Borrowing history of one book as a linked list (oldest record first)."""
        history = SinglyLinkedList()
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                "SELECT i.issue_id, s.name AS student_name, i.issue_date, i.due_date, i.return_date "
                "FROM book_issues i JOIN students s ON s.student_id = i.student_id "
                "WHERE i.book_id = ? ORDER BY i.issue_id", (book_id,)).fetchall()
        finally:
            conn.close()
        for r in rows:
            history.append(dict(r))
        return history

    # ------------------------------------------------------------------ reservations
    def reserve_book(self, book_id, student_id, today=None):
        today = _to_date(today)
        conn = get_connection(self.db_path)
        try:
            with conn:
                book = conn.execute("SELECT title, available_copies FROM books WHERE book_id = ?",
                                    (book_id,)).fetchone()
                student = conn.execute("SELECT name FROM students WHERE student_id = ?",
                                       (student_id,)).fetchone()
                if book is None:
                    raise ValueError("Book not found.")
                if student is None:
                    raise ValueError("Student is not registered.")
                if book["available_copies"] > 0:
                    raise ValueError("Copies are available, so issue the book instead of reserving it.")
                if conn.execute("SELECT 1 FROM book_issues WHERE book_id = ? AND student_id = ? "
                                "AND return_date IS NULL", (book_id, student_id)).fetchone():
                    raise ValueError("This student already has this book issued.")
                if conn.execute("SELECT 1 FROM reservations WHERE book_id = ? AND student_id = ? "
                                "AND status = 'WAITING'", (book_id, student_id)).fetchone():
                    raise ValueError("This student is already in the waiting list for this book.")
                cur = conn.execute(
                    "INSERT INTO reservations (book_id, student_id, reserved_on) VALUES (?, ?, ?)",
                    (book_id, student_id, today.strftime(DATE_FMT)))
                log_activity(conn, "RESERVE", f"{student['name']} reserved '{book['title']}'")
                return cur.lastrowid
        finally:
            conn.close()

    def get_reservation_queue(self, book_id):
        """Waiting list of a book as a Queue (front = next to be served)."""
        queue = Queue()
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                "SELECT r.reservation_id, r.student_id, s.name AS student_name, r.reserved_on "
                "FROM reservations r JOIN students s ON s.student_id = r.student_id "
                "WHERE r.book_id = ? AND r.status = 'WAITING' ORDER BY r.reservation_id",
                (book_id,)).fetchall()
        finally:
            conn.close()
        for r in rows:
            queue.enqueue(dict(r))
        return queue

    def get_all_waiting(self):
        """All waiting reservations with their position in each book's queue."""
        conn = get_connection(self.db_path)
        try:
            book_ids = [r["book_id"] for r in conn.execute(
                "SELECT DISTINCT book_id FROM reservations WHERE status = 'WAITING' ORDER BY book_id")]
            titles = {r["book_id"]: r["title"] for r in conn.execute("SELECT book_id, title FROM books")}
        finally:
            conn.close()
        result = []
        for book_id in book_ids:
            for pos, item in enumerate(self.get_reservation_queue(book_id).to_list(), start=1):
                item.update({"book_id": book_id, "title": titles[book_id], "position": pos})
                result.append(item)
        return result

    def cancel_reservation(self, reservation_id):
        conn = get_connection(self.db_path)
        try:
            with conn:
                cur = conn.execute("UPDATE reservations SET status = 'CANCELLED' "
                                   "WHERE reservation_id = ? AND status = 'WAITING'", (reservation_id,))
                if cur.rowcount == 0:
                    raise ValueError("Reservation not found or no longer waiting.")
                log_activity(conn, "CANCEL_RESERVATION", f"Cancelled reservation {reservation_id}")
        finally:
            conn.close()
