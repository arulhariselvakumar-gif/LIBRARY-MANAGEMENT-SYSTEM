"""Library Management System - DSA minor project.  Run with:  python main.py"""
import tkinter as tk
from tkinter import ttk, messagebox

from auth import AuthError  # noqa: F401  (kept so a missing module shows up at start-up)
from book_manager import BookManager
from database import init_db, DB_PATH
from issue_return import IssueReturnManager
from reports import ReportManager
from search_sort import SearchSortService
from student_manager import StudentManager
from ui.books import BooksFrame
from ui.dashboard import DashboardFrame
from ui.login import LoginFrame
from ui.reports import ReportsFrame
from ui.reservations import ReservationsFrame
from ui.search import SearchFrame
from ui.students import StudentsFrame
from ui.transactions import TransactionsFrame
from ui.widgets import setup_style, SIDEBAR, SIDEBAR_HOVER, FONT_BOLD

LOAN_DAYS = 14        # how many days a book can be kept
FINE_PER_DAY = 2      # fine for every day after the due date


class Services:
    """Holds every manager object so screens can share them."""

    def __init__(self, db_path):
        self.db_path = db_path
        self.books = BookManager(db_path)
        self.students = StudentManager(db_path)
        self.issues = IssueReturnManager(db_path, LOAN_DAYS, FINE_PER_DAY)
        self.search = SearchSortService(self.books)
        self.reports = ReportManager(db_path, self.issues)
        self.username = None


PAGES = [
    ("Dashboard", DashboardFrame),
    ("Books", BooksFrame),
    ("Students", StudentsFrame),
    ("Issue / Return", TransactionsFrame),
    ("Reservations", ReservationsFrame),
    ("Search & Sort", SearchFrame),
    ("Reports", ReportsFrame),
]


class LibraryApp(tk.Tk):
    def __init__(self, db_path=None):
        super().__init__()
        self.db_path = db_path or DB_PATH
        self.title("Library Management System")
        self.geometry("1180x720")
        self.minsize(1020, 640)
        setup_style(self)
        init_db(self.db_path)
        self.current = None
        self.pages = {}
        self.nav_buttons = {}
        self.root_frame = None
        self.show_login()

    def clear(self):
        if self.root_frame is not None:
            self.root_frame.destroy()
        self.root_frame = ttk.Frame(self)
        self.root_frame.pack(fill="both", expand=True)

    def show_login(self):
        self.svc = Services(self.db_path)          # fresh session (new undo stack)
        self.clear()
        LoginFrame(self.root_frame, self.svc, self.on_login).pack(fill="both", expand=True)

    def on_login(self, username):
        self.svc.username = username
        self.build_main()

    def build_main(self):
        self.clear()
        sidebar = tk.Frame(self.root_frame, bg=SIDEBAR, width=210)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        tk.Label(sidebar, text="Library\nManagement", bg=SIDEBAR, fg="white",
                 font=("Segoe UI", 15, "bold"), pady=18).pack()
        tk.Label(sidebar, text=f"Signed in as {self.svc.username}", bg=SIDEBAR, fg="#aab4cf").pack(pady=(0, 14))

        content = ttk.Frame(self.root_frame)
        content.pack(side="left", fill="both", expand=True)
        content.rowconfigure(0, weight=1)
        content.columnconfigure(0, weight=1)

        self.pages, self.nav_buttons = {}, {}
        for name, frame_class in PAGES:
            frame = frame_class(content, self.svc)
            frame.grid(row=0, column=0, sticky="nsew")
            self.pages[name] = frame
            button = tk.Button(sidebar, text=name, anchor="w", padx=22, pady=9, bd=0, bg=SIDEBAR,
                               fg="white", activebackground=SIDEBAR_HOVER, activeforeground="white",
                               font=FONT_BOLD, cursor="hand2", command=lambda n=name: self.show_page(n))
            button.pack(fill="x")
            self.nav_buttons[name] = button
        tk.Button(sidebar, text="Logout", anchor="w", padx=22, pady=9, bd=0, bg="#8f2d2d", fg="white",
                  activebackground="#b83030", activeforeground="white", font=FONT_BOLD,
                  cursor="hand2", command=self.logout).pack(side="bottom", fill="x")
        self.show_page("Dashboard")

    def show_page(self, name):
        for button_name, button in self.nav_buttons.items():
            button.config(bg=SIDEBAR_HOVER if button_name == name else SIDEBAR)
        page = self.pages[name]
        page.refresh()
        page.tkraise()
        self.current = name

    def logout(self):
        if messagebox.askyesno("Logout", "Do you want to log out?"):
            self.show_login()


if __name__ == "__main__":
    LibraryApp().mainloop()
