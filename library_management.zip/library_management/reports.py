"""Summary numbers for the dashboard/reports and CSV export."""
import csv

from database import get_connection


class ReportManager:
    def __init__(self, db_path, issue_manager):
        self.db_path = db_path
        self.issues = issue_manager

    def summary(self, today=None):
        conn = get_connection(self.db_path)
        try:
            titles, copies, available = conn.execute(
                "SELECT COUNT(*), COALESCE(SUM(quantity), 0), COALESCE(SUM(available_copies), 0) FROM books"
            ).fetchone()
            students = conn.execute("SELECT COUNT(*) FROM students").fetchone()[0]
            waiting = conn.execute("SELECT COUNT(*) FROM reservations WHERE status = 'WAITING'").fetchone()[0]
        finally:
            conn.close()
        return {
            "total_titles": titles,
            "total_copies": copies,
            "available_copies": available,
            "issued_copies": copies - available,
            "students": students,
            "currently_issued": len(self.issues.get_active_issues(today)),
            "overdue": len(self.issues.get_overdue(today)),
            "waiting_reservations": waiting,
        }

    @staticmethod
    def export_csv(path, headers, rows):
        """Write rows (list of dicts) to a CSV file. `headers` are the dict keys, in order."""
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            for row in rows:
                writer.writerow([row.get(h, "") for h in headers])
        return len(rows)
