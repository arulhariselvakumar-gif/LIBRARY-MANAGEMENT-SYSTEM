"""Glue between the screens and the dsa/ package: search + sort book records."""
from dsa.binary_search_tree import BinarySearchTree
from dsa.searching import linear_search, binary_search
from dsa.sorting import bubble_sort_counted, merge_sort

COMPLEXITY = {
    "Linear Search": "Time O(n), Space O(1) extra",
    "Binary Search": "Time O(log n) (list must be sorted), Space O(1)",
    "BST Prefix Search": "Time O(log n + k) on a balanced tree, O(n) worst case; Space O(n) for the tree",
    "Merge Sort": "Time O(n log n) best/average/worst, Space O(n)",
    "Bubble Sort": "Time O(n) best, O(n^2) average/worst, Space O(1)",
}

SEARCH_FIELDS = ["Book ID", "Title", "Author", "Category"]
SORT_FIELDS = {"Title": "title", "Author": "author", "Available Quantity": "available_copies"}


class SearchSortService:
    def __init__(self, book_manager):
        self.books = book_manager

    # ------------------------------------------------------------------ search
    def search(self, field, query):
        """Return {"results", "algorithm", "complexity", "comparisons", "message"}."""
        query = (query or "").strip()
        if not query:
            raise ValueError("Please type something to search for.")
        books = self.books.get_all_books()
        if field == "Book ID":
            return self._search_id(books, query)
        if field == "Title":
            return self._search_title(books, query)
        if field == "Author":
            return self._linear(books, "author", query)
        if field == "Category":
            return self._linear(books, "category", query)
        raise ValueError("Unknown search field.")

    def _result(self, results, algorithm, comparisons, name_for_complexity):
        return {
            "results": results,
            "algorithm": algorithm,
            "complexity": COMPLEXITY[name_for_complexity],
            "comparisons": comparisons,
            "message": "" if results else "No matching books found.",
        }

    def _search_id(self, books, query):
        try:
            target = int(query)
        except ValueError:
            raise ValueError("Book ID must be a number.")
        ordered = merge_sort(books, key=lambda b: b["book_id"])      # binary search needs sorted data
        index, comps = binary_search(ordered, "book_id", target)
        found = [ordered[index]] if index >= 0 else []
        return self._result(found, "Binary Search (list sorted by Merge Sort)", comps, "Binary Search")

    def _search_title(self, books, query):
        tree = BinarySearchTree()
        for book in books:
            tree.insert(book["title"].lower(), book)
        found = tree.prefix_search(query.lower())
        if found:
            return self._result(found, "BST Prefix Search (title starts with the text)", 0, "BST Prefix Search")
        # nothing starts with the text -> look for the text anywhere inside the title
        found, comps = linear_search(books, "title", query)
        out = self._result(found, "BST prefix search found nothing -> Linear Search (text inside title)",
                           comps, "Linear Search")
        return out

    def _linear(self, books, field, query):
        found, comps = linear_search(books, field, query)
        return self._result(found, "Linear Search", comps, "Linear Search")

    # ------------------------------------------------------------------ sort
    def sort_books(self, field_label, algorithm="Merge Sort", descending=False):
        """Sort every book by Title / Author / Available Quantity with the chosen algorithm."""
        if field_label not in SORT_FIELDS:
            raise ValueError("Unknown sort field.")
        field = SORT_FIELDS[field_label]
        if field == "available_copies":
            key = lambda b: b[field]
        else:
            key = lambda b: b[field].lower()
        books = self.books.get_all_books()
        comparisons = None
        if algorithm == "Bubble Sort":
            ordered, comparisons, swaps = bubble_sort_counted(books, key=key, reverse=descending)
            note = f"{comparisons} comparisons, {swaps} swaps"
        elif algorithm == "Merge Sort":
            ordered = merge_sort(books, key=key, reverse=descending)
            note = "Divide, sort halves, merge"
        else:
            raise ValueError("Unknown sorting algorithm.")
        return {"results": ordered, "algorithm": algorithm, "complexity": COMPLEXITY[algorithm],
                "comparisons": comparisons, "message": note}
