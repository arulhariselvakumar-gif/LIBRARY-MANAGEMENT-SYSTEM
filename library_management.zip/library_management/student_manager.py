"""Register / view / search / update / delete students."""
import sqlite3

from database import get_connection, log_activity


class StudentManager:
    def __init__(self, db_path=None):
        self.db_path = db_path

    @staticmethod
    def _clean(reg_no, name, department, email, phone):
        reg_no, name = (reg_no or "").strip(), (name or "").strip()
        if not reg_no or not name:
            raise ValueError("Register number and name are required.")
        email = (email or "").strip()
        phone = (phone or "").strip()
        if email and ("@" not in email or "." not in email.split("@")[-1]):
            raise ValueError("Please enter a valid email address.")
        if phone and not (phone.isdigit() and 7 <= len(phone) <= 15):
            raise ValueError("Phone must contain 7 to 15 digits only.")
        return reg_no, name, (department or "").strip(), email, phone

    def add_student(self, reg_no, name, department="", email="", phone=""):
        reg_no, name, department, email, phone = self._clean(reg_no, name, department, email, phone)
        conn = get_connection(self.db_path)
        try:
            with conn:
                cur = conn.execute(
                    "INSERT INTO students (reg_no, name, department, email, phone) VALUES (?, ?, ?, ?, ?)",
                    (reg_no, name, department, email, phone),
                )
                log_activity(conn, "ADD_STUDENT", f"Registered student '{name}' ({reg_no})")
                return cur.lastrowid
        except sqlite3.IntegrityError:
            raise ValueError(f"Register number {reg_no} is already registered.")
        finally:
            conn.close()

    def get_all_students(self):
        conn = get_connection(self.db_path)
        try:
            return [dict(r) for r in conn.execute("SELECT * FROM students ORDER BY student_id")]
        finally:
            conn.close()

    def get_student(self, student_id):
        conn = get_connection(self.db_path)
        try:
            row = conn.execute("SELECT * FROM students WHERE student_id = ?", (student_id,)).fetchone()
            return dict(row) if row else None
        finally:
            conn.close()

    def search_students(self, term):
        """Search by exact student ID, or by part of the name / register number."""
        term = (term or "").strip()
        if not term:
            return self.get_all_students()
        like = f"%{term.lower()}%"
        conn = get_connection(self.db_path)
        try:
            rows = conn.execute(
                "SELECT * FROM students WHERE CAST(student_id AS TEXT) = ? "
                "OR LOWER(name) LIKE ? OR LOWER(reg_no) LIKE ? ORDER BY student_id",
                (term, like, like),
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def update_student(self, student_id, reg_no, name, department="", email="", phone=""):
        reg_no, name, department, email, phone = self._clean(reg_no, name, department, email, phone)
        conn = get_connection(self.db_path)
        try:
            with conn:
                cur = conn.execute(
                    "UPDATE students SET reg_no=?, name=?, department=?, email=?, phone=? WHERE student_id=?",
                    (reg_no, name, department, email, phone, student_id),
                )
                if cur.rowcount == 0:
                    raise ValueError("Student not found.")
                log_activity(conn, "UPDATE_STUDENT", f"Updated student ID {student_id}")
        except sqlite3.IntegrityError:
            raise ValueError(f"Register number {reg_no} is already used by another student.")
        finally:
            conn.close()

    def delete_student(self, student_id):
        """Delete only if the student has no issue or reservation records."""
        conn = get_connection(self.db_path)
        try:
            with conn:
                if conn.execute("SELECT 1 FROM students WHERE student_id = ?", (student_id,)).fetchone() is None:
                    raise ValueError("Student not found.")
                used = conn.execute("SELECT 1 FROM book_issues WHERE student_id = ? LIMIT 1", (student_id,)).fetchone()
                reserved = conn.execute("SELECT 1 FROM reservations WHERE student_id = ? LIMIT 1", (student_id,)).fetchone()
                if used or reserved:
                    raise ValueError("This student has issue/reservation records, so cannot be deleted.")
                conn.execute("DELETE FROM students WHERE student_id = ?", (student_id,))
                log_activity(conn, "DELETE_STUDENT", f"Deleted student ID {student_id}")
        finally:
            conn.close()
