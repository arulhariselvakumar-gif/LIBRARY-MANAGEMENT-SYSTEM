"""Unit tests for the data structures and algorithms."""
import random
import unittest

from dsa.linked_list import SinglyLinkedList
from dsa.stack import Stack, EmptyStackError
from dsa.queue import Queue, EmptyQueueError
from dsa.binary_search_tree import BinarySearchTree
from dsa.searching import linear_search, binary_search
from dsa.sorting import bubble_sort, bubble_sort_counted, merge_sort


class TestLinkedList(unittest.TestCase):
    def test_append_prepend_order(self):
        ll = SinglyLinkedList()
        ll.append(2)
        ll.append(3)
        ll.prepend(1)
        self.assertEqual(ll.to_list(), [1, 2, 3])
        self.assertEqual(len(ll), 3)

    def test_remove_middle_head_tail(self):
        ll = SinglyLinkedList()
        for x in [1, 2, 3, 4]:
            ll.append(x)
        self.assertTrue(ll.remove(2))
        self.assertTrue(ll.remove(1))
        self.assertTrue(ll.remove(4))
        self.assertEqual(ll.to_list(), [3])
        ll.append(9)                      # tail must still be correct
        self.assertEqual(ll.to_list(), [3, 9])
        self.assertFalse(ll.remove(100))

    def test_empty_and_find(self):
        ll = SinglyLinkedList()
        self.assertTrue(ll.is_empty())
        self.assertIsNone(ll.find(lambda x: True))
        ll.append({"id": 5})
        self.assertEqual(ll.find(lambda d: d["id"] == 5), {"id": 5})


class TestStack(unittest.TestCase):
    def test_lifo(self):
        s = Stack()
        s.push("a")
        s.push("b")
        self.assertEqual(s.peek(), "b")
        self.assertEqual(s.pop(), "b")
        self.assertEqual(s.pop(), "a")
        self.assertTrue(s.is_empty())

    def test_empty_errors(self):
        s = Stack()
        with self.assertRaises(EmptyStackError):
            s.pop()
        with self.assertRaises(EmptyStackError):
            s.peek()

    def test_to_list_newest_first(self):
        s = Stack()
        for x in [1, 2, 3]:
            s.push(x)
        self.assertEqual(s.to_list(), [3, 2, 1])


class TestQueue(unittest.TestCase):
    def test_fifo(self):
        q = Queue()
        for x in [1, 2, 3]:
            q.enqueue(x)
        self.assertEqual(q.peek(), 1)
        self.assertEqual(q.dequeue(), 1)
        self.assertEqual(q.to_list(), [2, 3])
        self.assertEqual(q.size(), 2)

    def test_empty_errors_and_reuse(self):
        q = Queue()
        with self.assertRaises(EmptyQueueError):
            q.dequeue()
        with self.assertRaises(EmptyQueueError):
            q.peek()
        q.enqueue("x")
        q.dequeue()
        q.enqueue("y")                    # rear pointer must be reset correctly
        self.assertEqual(q.to_list(), ["y"])


class TestBST(unittest.TestCase):
    def setUp(self):
        self.t = BinarySearchTree()
        for key, val in [("python", 1), ("java", 2), ("c", 3), ("python", 4),
                         ("pandas", 5), ("sql", 6)]:
            self.t.insert(key, val)

    def test_search_exact_and_duplicates(self):
        self.assertEqual(sorted(self.t.search("python")), [1, 4])
        self.assertEqual(self.t.search("missing"), [])

    def test_inorder_is_sorted_by_key(self):
        self.assertEqual(self.t.inorder(), [3, 2, 5, 1, 4, 6])

    def test_prefix_search(self):
        self.assertEqual(self.t.prefix_search("p"), [5, 1, 4])
        self.assertEqual(self.t.prefix_search("pa"), [5])
        self.assertEqual(self.t.prefix_search("zzz"), [])

    def test_height_size_empty(self):
        self.assertEqual(self.t.size(), 6)
        self.assertGreaterEqual(self.t.height(), 3)
        e = BinarySearchTree()
        self.assertTrue(e.is_empty())
        self.assertEqual(e.height(), 0)
        self.assertEqual(e.prefix_search("a"), [])

    def test_prefix_matches_brute_force(self):
        random.seed(1)
        words = ["".join(random.choice("abc") for _ in range(random.randint(1, 5)))
                 for _ in range(200)]
        tree = BinarySearchTree()
        for i, w in enumerate(words):
            tree.insert(w, (w, i))
        for prefix in ["a", "ab", "abc", "ba", "c", "cc"]:
            expected = sorted(v for v in ((w, i) for i, w in enumerate(words))
                              if v[0].startswith(prefix))
            got = tree.prefix_search(prefix)
            self.assertEqual(sorted(got), expected)


class TestSearching(unittest.TestCase):
    def setUp(self):
        self.rows = [{"id": 1, "title": "Python Basics"},
                     {"id": 3, "title": "Java Notes"},
                     {"id": 5, "title": "Advanced Python"},
                     {"id": 8, "title": "SQL Guide"}]

    def test_linear_partial_case_insensitive(self):
        found, comps = linear_search(self.rows, "title", "python")
        self.assertEqual([r["id"] for r in found], [1, 5])
        self.assertEqual(comps, 4)

    def test_linear_exact_and_not_found(self):
        self.assertEqual(linear_search(self.rows, "title", "sql guide", exact=True)[0],
                         [self.rows[3]])
        self.assertEqual(linear_search(self.rows, "title", "ruby")[0], [])

    def test_binary_search_found_and_missing(self):
        self.assertEqual(binary_search(self.rows, "id", 5)[0], 2)
        self.assertEqual(binary_search(self.rows, "id", 1)[0], 0)
        self.assertEqual(binary_search(self.rows, "id", 8)[0], 3)
        self.assertEqual(binary_search(self.rows, "id", 4)[0], -1)
        self.assertEqual(binary_search([], "id", 1)[0], -1)


class TestSorting(unittest.TestCase):
    def test_both_sorts_match_python_sorted(self):
        random.seed(7)
        for size in [0, 1, 2, 5, 50, 200]:
            data = [random.randint(-50, 50) for _ in range(size)]
            self.assertEqual(bubble_sort(data), sorted(data))
            self.assertEqual(merge_sort(data), sorted(data))
            self.assertEqual(bubble_sort(data, reverse=True), sorted(data, reverse=True))
            self.assertEqual(merge_sort(data, reverse=True), sorted(data, reverse=True))

    def test_key_function_and_input_untouched(self):
        books = [{"t": "b", "q": 2}, {"t": "a", "q": 9}, {"t": "c", "q": 5}]
        original = list(books)
        self.assertEqual([b["t"] for b in merge_sort(books, key=lambda b: b["t"])],
                         ["a", "b", "c"])
        self.assertEqual([b["q"] for b in bubble_sort(books, key=lambda b: b["q"])],
                         [2, 5, 9])
        self.assertEqual(books, original)

    def test_merge_sort_is_stable(self):
        rows = [{"k": 1, "n": "first"}, {"k": 0, "n": "x"}, {"k": 1, "n": "second"}]
        out = merge_sort(rows, key=lambda r: r["k"])
        self.assertEqual([r["n"] for r in out], ["x", "first", "second"])

    def test_bubble_counts_and_early_exit(self):
        _, comps, swaps = bubble_sort_counted([1, 2, 3, 4])
        self.assertEqual((comps, swaps), (3, 0))      # best case: one pass
        _, comps, swaps = bubble_sort_counted([4, 3, 2, 1])
        self.assertEqual(swaps, 6)


if __name__ == "__main__":
    unittest.main()
