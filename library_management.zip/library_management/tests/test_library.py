"""Tests for database, login, managers, issue/return, reservations and search/sort.

Every test uses its own temporary database, so your real library.db is never touched.
"""
import csv
import os
import shutil
import tempfile
import unittest
from datetime import date, timedelta

from auth import login, AuthError, hash_password, verify_password
from book_manager import BookManager
from database import init_db, get_connection
from issue_return import IssueReturnManager
from reports import ReportManager
from search_sort import SearchSortService
from student_manager import StudentManager


class LibraryTestCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.db = os.path.join(self.tmp, "test.db")
        init_db(self.db, with_sample_data=False)
        self.books = BookManager(self.db)
        self.students = StudentManager(self.db)
        self.ir = IssueReturnManager(self.db, loan_days=14, fine_per_day=2)
        self.b1 = self.books.add_book("Python Basics", "Guido", "Programming", "ISBN-1", 2)
        self.b2 = self.books.add_book("Advanced Python", "Tim", "Programming", "ISBN-2", 1)
        self.b3 = self.books.add_book("Data Structures", "Reema", "Computer Science", "ISBN-3", 3)
        self.s1 = self.students.add_student("R1", "Arun", "AIDS", "a@x.com", "9000000001")
        self.s2 = self.students.add_student("R2", "Priya")
        self.s3 = self.students.add_student("R3", "Karthik")

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def available(self, book_id):
        return self.books.get_book(book_id)["available_copies"]


class TestLogin(LibraryTestCase):
    def test_successful_login(self):
        self.assertEqual(login("admin", "admin123", self.db), "admin")

    def test_wrong_password_empty_and_unknown_user(self):
        with self.assertRaises(AuthError):
            login("admin", "wrong", self.db)
        with self.assertRaises(AuthError):
            login("", "", self.db)
        with self.assertRaises(AuthError):
            login("nobody", "admin123", self.db)

    def test_password_is_hashed_not_plain(self):
        conn = get_connection(self.db)
        stored = conn.execute("SELECT password_hash FROM users").fetchone()[0]
        conn.close()
        self.assertNotIn("admin123", stored)
        h, salt = hash_password("secret")
        self.assertTrue(verify_password("secret", h, salt))
        self.assertFalse(verify_password("Secret", h, salt))


class TestBooks(LibraryTestCase):
    def test_add_and_get(self):
        bid = self.books.add_book("New", "Auth", "Cat", "ISBN-9", 4)
        book = self.books.get_book(bid)
        self.assertEqual((book["quantity"], book["available_copies"]), (4, 4))

    def test_duplicate_isbn_rejected(self):
        with self.assertRaises(ValueError):
            self.books.add_book("Other", "A", "C", "ISBN-1", 1)

    def test_validation(self):
        with self.assertRaises(ValueError):
            self.books.add_book("", "A", "C", "I", 1)
        with self.assertRaises(ValueError):
            self.books.add_book("T", "A", "C", "I", "abc")
        with self.assertRaises(ValueError):
            self.books.add_book("T", "A", "C", "I", -1)

    def test_update_changes_available_with_quantity(self):
        self.ir.issue_book(self.b1, self.s1)                 # 2 copies, 1 available
        self.books.update_book(self.b1, "Python Basics 2e", "Guido", "Programming", "ISBN-1", 5)
        book = self.books.get_book(self.b1)
        self.assertEqual((book["title"], book["quantity"], book["available_copies"]),
                         ("Python Basics 2e", 5, 4))

    def test_update_cannot_go_below_issued(self):
        self.ir.issue_book(self.b1, self.s1)
        self.ir.issue_book(self.b1, self.s2)                 # both copies issued
        with self.assertRaises(ValueError):
            self.books.update_book(self.b1, "Python Basics", "Guido", "Programming", "ISBN-1", 1)

    def test_delete_unused_ok_and_used_blocked(self):
        self.books.delete_book(self.b3)
        self.assertIsNone(self.books.get_book(self.b3))
        self.ir.issue_book(self.b1, self.s1)
        with self.assertRaises(ValueError):
            self.books.delete_book(self.b1)
        with self.assertRaises(ValueError):
            self.books.delete_book(9999)


class TestStudents(LibraryTestCase):
    def test_duplicate_reg_no_and_validation(self):
        with self.assertRaises(ValueError):
            self.students.add_student("R1", "Someone")
        with self.assertRaises(ValueError):
            self.students.add_student("R9", "X", email="bad-email")
        with self.assertRaises(ValueError):
            self.students.add_student("R9", "X", phone="12ab")

    def test_search_by_id_and_name(self):
        self.assertEqual([s["name"] for s in self.students.search_students(str(self.s2))], ["Priya"])
        self.assertEqual([s["name"] for s in self.students.search_students("kart")], ["Karthik"])
        self.assertEqual(self.students.search_students("zzz"), [])

    def test_update_and_delete_rules(self):
        self.students.update_student(self.s3, "R3", "Karthik Raja", "CS", "", "")
        self.assertEqual(self.students.get_student(self.s3)["name"], "Karthik Raja")
        self.students.delete_student(self.s3)
        self.assertIsNone(self.students.get_student(self.s3))
        self.ir.issue_book(self.b1, self.s1)
        with self.assertRaises(ValueError):
            self.students.delete_student(self.s1)


class TestIssueReturn(LibraryTestCase):
    def test_issue_reduces_available_and_sets_due_date(self):
        iid = self.ir.issue_book(self.b1, self.s1, today=date(2026, 1, 1))
        self.assertEqual(self.available(self.b1), 1)
        issue = self.ir.get_active_issues(today=date(2026, 1, 1))[0]
        self.assertEqual((issue["issue_id"], issue["due_date"]), (iid, "2026-01-15"))

    def test_cannot_issue_unavailable_book(self):
        self.ir.issue_book(self.b2, self.s1)                 # only 1 copy
        with self.assertRaises(ValueError):
            self.ir.issue_book(self.b2, self.s2)
        self.assertEqual(self.available(self.b2), 0)

    def test_duplicate_active_issue_blocked(self):
        self.ir.issue_book(self.b1, self.s1)
        with self.assertRaises(ValueError):
            self.ir.issue_book(self.b1, self.s1)
        self.assertEqual(self.available(self.b1), 1)         # no copy was lost

    def test_unknown_book_or_student(self):
        with self.assertRaises(ValueError):
            self.ir.issue_book(9999, self.s1)
        with self.assertRaises(ValueError):
            self.ir.issue_book(self.b1, 9999)

    def test_return_restores_copy(self):
        iid = self.ir.issue_book(self.b1, self.s1)
        result = self.ir.return_book(iid)
        self.assertEqual((result["overdue_days"], result["fine"]), (0, 0))
        self.assertEqual(self.available(self.b1), 2)
        self.assertEqual(self.ir.get_active_issues(), [])

    def test_invalid_returns(self):
        with self.assertRaises(ValueError):
            self.ir.return_book(12345)
        iid = self.ir.issue_book(self.b1, self.s1)
        self.ir.return_book(iid)
        with self.assertRaises(ValueError):
            self.ir.return_book(iid)                         # second return
        self.assertEqual(self.available(self.b1), 2)

    def test_overdue_and_fine(self):
        iid = self.ir.issue_book(self.b1, self.s1, today=date(2026, 1, 1))   # due 15 Jan
        self.assertEqual(self.ir.get_overdue(today=date(2026, 1, 15)), [])    # due today = not late
        late = self.ir.get_overdue(today=date(2026, 1, 20))
        self.assertEqual((len(late), late[0]["overdue_days"], late[0]["fine"]), (1, 5, 10))
        result = self.ir.return_book(iid, today=date(2026, 1, 20))
        self.assertEqual((result["overdue_days"], result["fine"]), (5, 10))

    def test_book_history_is_linked_list_in_order(self):
        i1 = self.ir.issue_book(self.b1, self.s1)
        self.ir.return_book(i1)
        self.ir.issue_book(self.b1, self.s2)
        history = self.ir.get_book_history(self.b1)
        self.assertEqual([h["student_name"] for h in history], ["Arun", "Priya"])
        self.assertIsNotNone(history.to_list()[0]["return_date"])
        self.assertIsNone(history.to_list()[1]["return_date"])

    def test_rollback_when_issue_fails_midway(self):
        """A failed issue must leave available_copies unchanged (transaction safety)."""
        self.ir.issue_book(self.b1, self.s1)
        try:
            self.ir.issue_book(self.b1, self.s1)
        except ValueError:
            pass
        self.assertEqual(self.available(self.b1), 1)
        conn = get_connection(self.db)
        count = conn.execute("SELECT COUNT(*) FROM book_issues").fetchone()[0]
        conn.close()
        self.assertEqual(count, 1)


class TestUndo(LibraryTestCase):
    def test_undo_empty_stack(self):
        with self.assertRaises(ValueError):
            self.ir.undo_last()

    def test_undo_issue(self):
        self.ir.issue_book(self.b1, self.s1)
        self.ir.undo_last()
        self.assertEqual(self.available(self.b1), 2)
        self.assertEqual(self.ir.get_active_issues(), [])

    def test_undo_return(self):
        iid = self.ir.issue_book(self.b1, self.s1)
        self.ir.return_book(iid)
        self.ir.undo_last()
        self.assertEqual(self.available(self.b1), 1)
        self.assertEqual(len(self.ir.get_active_issues()), 1)

    def test_recent_activity_newest_first(self):
        self.ir.issue_book(self.b1, self.s1)
        self.ir.issue_book(self.b3, self.s2)
        recent = self.ir.recent_activity()
        self.assertIn("Data Structures", recent[0])
        self.assertIn("Python Basics", recent[1])


class TestReservations(LibraryTestCase):
    def setUp(self):
        super().setUp()
        self.issue_id = self.ir.issue_book(self.b2, self.s1)     # b2 now has 0 copies

    def test_cannot_reserve_when_available(self):
        with self.assertRaises(ValueError):
            self.ir.reserve_book(self.b3, self.s1)

    def test_queue_order_and_duplicates(self):
        self.ir.reserve_book(self.b2, self.s2)
        self.ir.reserve_book(self.b2, self.s3)
        names = [r["student_name"] for r in self.ir.get_reservation_queue(self.b2).to_list()]
        self.assertEqual(names, ["Priya", "Karthik"])
        with self.assertRaises(ValueError):
            self.ir.reserve_book(self.b2, self.s2)               # already waiting
        with self.assertRaises(ValueError):
            self.ir.reserve_book(self.b2, self.s1)               # already holds the book

    def test_return_serves_first_in_queue(self):
        self.ir.reserve_book(self.b2, self.s2)
        self.ir.reserve_book(self.b2, self.s3)
        result = self.ir.return_book(self.issue_id)
        self.assertEqual(result["auto_issued_to"], "Priya")
        self.assertEqual(self.available(self.b2), 0)             # copy went straight to Priya
        holders = [i["student_name"] for i in self.ir.get_active_issues()]
        self.assertEqual(holders, ["Priya"])
        remaining = [r["student_name"] for r in self.ir.get_reservation_queue(self.b2).to_list()]
        self.assertEqual(remaining, ["Karthik"])

    def test_empty_queue_return_just_restores(self):
        result = self.ir.return_book(self.issue_id)
        self.assertIsNone(result["auto_issued_to"])
        self.assertEqual(self.available(self.b2), 1)
        self.assertTrue(self.ir.get_reservation_queue(self.b2).is_empty())

    def test_cancel_reservation_and_waiting_positions(self):
        r1 = self.ir.reserve_book(self.b2, self.s2)
        self.ir.reserve_book(self.b2, self.s3)
        self.ir.cancel_reservation(r1)
        waiting = self.ir.get_all_waiting()
        self.assertEqual([(w["student_name"], w["position"]) for w in waiting], [("Karthik", 1)])
        with self.assertRaises(ValueError):
            self.ir.cancel_reservation(r1)

    def test_auto_issue_cannot_be_undone(self):
        self.ir.reserve_book(self.b2, self.s2)
        self.ir.return_book(self.issue_id)
        with self.assertRaises(ValueError):
            self.ir.undo_last()


class TestSearchSort(LibraryTestCase):
    def setUp(self):
        super().setUp()
        self.svc = SearchSortService(self.books)

    def titles(self, result):
        return [b["title"] for b in result["results"]]

    def test_search_by_id_binary_search(self):
        r = self.svc.search("Book ID", str(self.b2))
        self.assertEqual(self.titles(r), ["Advanced Python"])
        self.assertIn("Binary", r["algorithm"])

    def test_search_id_not_found_and_invalid(self):
        r = self.svc.search("Book ID", "9999")
        self.assertEqual((r["results"], r["message"]), ([], "No matching books found."))
        with self.assertRaises(ValueError):
            self.svc.search("Book ID", "abc")

    def test_search_title_prefix_uses_bst(self):
        r = self.svc.search("Title", "python")
        self.assertEqual(self.titles(r), ["Python Basics"])
        self.assertIn("BST", r["algorithm"])

    def test_search_title_falls_back_to_linear(self):
        r = self.svc.search("Title", "python")
        r2 = self.svc.search("Title", "structures")
        self.assertEqual(self.titles(r2), ["Data Structures"])
        self.assertIn("Linear", r2["algorithm"])
        self.assertNotEqual(r["algorithm"], r2["algorithm"])

    def test_search_author_category_and_missing(self):
        self.assertEqual(self.titles(self.svc.search("Author", "tim")), ["Advanced Python"])
        self.assertEqual(len(self.svc.search("Category", "programming")["results"]), 2)
        self.assertEqual(self.svc.search("Title", "zzzz")["results"], [])
        with self.assertRaises(ValueError):
            self.svc.search("Title", "   ")

    def test_sort_all_fields_both_algorithms_match_python(self):
        books = self.books.get_all_books()
        for label, field in [("Title", "title"), ("Author", "author"),
                             ("Available Quantity", "available_copies")]:
            for algo in ("Merge Sort", "Bubble Sort"):
                for desc in (False, True):
                    got = [b[field] for b in self.svc.sort_books(label, algo, desc)["results"]]
                    keyf = (lambda x: x) if field == "available_copies" else (lambda x: x.lower())
                    expected = sorted((b[field] for b in books), key=keyf, reverse=desc)
                    self.assertEqual(got, expected, f"{label}/{algo}/desc={desc}")

    def test_sort_unknown_options(self):
        with self.assertRaises(ValueError):
            self.svc.sort_books("Colour")
        with self.assertRaises(ValueError):
            self.svc.sort_books("Title", "Quick Sort")


class TestReportsAndPersistence(LibraryTestCase):
    def test_summary_numbers(self):
        self.ir.issue_book(self.b1, self.s1, today=date(2026, 1, 1))
        self.ir.issue_book(self.b2, self.s2, today=date(2026, 1, 1))
        self.ir.reserve_book(self.b2, self.s3)
        rep = ReportManager(self.db, self.ir)
        s = rep.summary(today=date(2026, 2, 1))
        self.assertEqual(s["total_titles"], 3)
        self.assertEqual(s["total_copies"], 6)
        self.assertEqual(s["issued_copies"], 2)
        self.assertEqual(s["available_copies"], 4)
        self.assertEqual(s["students"], 3)
        self.assertEqual(s["currently_issued"], 2)
        self.assertEqual(s["overdue"], 2)
        self.assertEqual(s["waiting_reservations"], 1)

    def test_csv_export(self):
        rep = ReportManager(self.db, self.ir)
        path = os.path.join(self.tmp, "books.csv")
        n = rep.export_csv(path, ["book_id", "title"], self.books.get_all_books())
        self.assertEqual(n, 3)
        with open(path, newline="", encoding="utf-8") as f:
            rows = list(csv.reader(f))
        self.assertEqual(rows[0], ["book_id", "title"])
        self.assertEqual(len(rows), 4)

    def test_data_persists_after_restart(self):
        iid = self.ir.issue_book(self.b1, self.s1)
        # "restart": brand-new manager objects reading the same database file
        books2, ir2 = BookManager(self.db), IssueReturnManager(self.db)
        init_db(self.db, with_sample_data=False)              # init again must not wipe or duplicate
        self.assertEqual(len(books2.get_all_books()), 3)
        self.assertEqual(books2.get_book(self.b1)["available_copies"], 1)
        self.assertEqual([i["issue_id"] for i in ir2.get_active_issues()], [iid])
        self.assertEqual(login("admin", "admin123", self.db), "admin")

    def test_activity_log_written(self):
        self.ir.issue_book(self.b1, self.s1)
        actions = [r["action"] for r in self.ir.activity_log(50)]
        self.assertIn("ISSUE", actions)
        self.assertIn("ADD_BOOK", actions)


if __name__ == "__main__":
    unittest.main()
