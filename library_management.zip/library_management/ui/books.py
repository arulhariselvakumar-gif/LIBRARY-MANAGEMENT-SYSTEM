"""Book management screen (add / update / delete / view + borrowing history from a linked list)."""
import tkinter as tk
from tkinter import ttk, messagebox

from ui.widgets import DataTable, page_header

FIELDS = [("title", "Title"), ("author", "Author"), ("category", "Category"),
          ("isbn", "ISBN"), ("quantity", "Quantity")]


class BooksFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        self.selected_id = None
        page_header(self, "Book Management", "Add, update, delete and view books").pack(anchor="w")

        form = ttk.LabelFrame(self, text="Book details", padding=10)
        form.pack(fill="x", pady=8)
        self.entries = {}
        for i, (key, label) in enumerate(FIELDS):
            ttk.Label(form, text=label).grid(row=0, column=i, sticky="w", padx=4)
            entry = ttk.Entry(form, width=22 if key != "quantity" else 10)
            entry.grid(row=1, column=i, padx=4, pady=(0, 4), sticky="w")
            self.entries[key] = entry

        buttons = ttk.Frame(form)
        buttons.grid(row=2, column=0, columnspan=len(FIELDS), sticky="w", pady=(6, 0))
        ttk.Button(buttons, text="Add Book", style="Accent.TButton", command=self.add).pack(side="left", padx=4)
        ttk.Button(buttons, text="Update Selected", command=self.update).pack(side="left", padx=4)
        ttk.Button(buttons, text="Delete Selected", style="Danger.TButton", command=self.delete).pack(side="left", padx=4)
        ttk.Button(buttons, text="Borrowing History", command=self.show_history).pack(side="left", padx=4)
        ttk.Button(buttons, text="Clear", command=self.clear_form).pack(side="left", padx=4)

        self.table = DataTable(self, [
            ("book_id", "ID", 50), ("title", "Title", 260), ("author", "Author", 160),
            ("category", "Category", 140), ("isbn", "ISBN", 120),
            ("quantity", "Qty", 60), ("available_copies", "Available", 80)], height=14)
        self.table.pack(fill="both", expand=True)
        self.table.on_select(self.on_row_selected)

    def refresh(self):
        self.table.set_rows(self.svc.books.get_all_books(),
                            tag_func=lambda r: "low" if r["available_copies"] == 0 else None)
        self.selected_id = None

    def values(self):
        return [self.entries[k].get() for k, _ in FIELDS]

    def clear_form(self):
        for entry in self.entries.values():
            entry.delete(0, "end")
        self.selected_id = None

    def on_row_selected(self):
        row = self.table.selected_row()
        if not row:
            return
        self.selected_id = row["book_id"]
        for key, _ in FIELDS:
            self.entries[key].delete(0, "end")
            self.entries[key].insert(0, str(row[key]))

    def add(self):
        try:
            new_id = self.svc.books.add_book(*self.values())
        except ValueError as err:
            messagebox.showerror("Cannot add book", str(err))
            return
        messagebox.showinfo("Success", f"Book added with ID {new_id}.")
        self.clear_form()
        self.refresh()

    def update(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a book", "Click a book in the table first.")
            return
        try:
            self.svc.books.update_book(self.selected_id, *self.values())
        except ValueError as err:
            messagebox.showerror("Cannot update book", str(err))
            return
        messagebox.showinfo("Success", "Book updated.")
        self.clear_form()
        self.refresh()

    def delete(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a book", "Click a book in the table first.")
            return
        if not messagebox.askyesno("Confirm delete", "Delete the selected book permanently?"):
            return
        try:
            self.svc.books.delete_book(self.selected_id)
        except ValueError as err:
            messagebox.showerror("Cannot delete book", str(err))
            return
        messagebox.showinfo("Success", "Book deleted.")
        self.clear_form()
        self.refresh()

    def show_history(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a book", "Click a book in the table first.")
            return
        history = self.svc.issues.get_book_history(self.selected_id)      # singly linked list
        win = tk.Toplevel(self)
        win.title(f"Borrowing history - book ID {self.selected_id}")
        win.geometry("640x320")
        ttk.Label(win, text=f"{len(history)} record(s), oldest first (linked list order)",
                  padding=8).pack(anchor="w")
        table = DataTable(win, [("student_name", "Student", 160), ("issue_date", "Issued", 100),
                                ("due_date", "Due", 100), ("return_date", "Returned", 100)], height=10)
        table.pack(fill="both", expand=True, padx=8, pady=8)
        table.set_rows(history.to_list())
