"""Dashboard: summary cards, recent activity (Stack) and the permanent activity log."""
import tkinter as tk
from tkinter import ttk

from ui.widgets import DataTable, page_header, ACCENT, MUTED

CARDS = [
    ("total_titles", "Book Titles"), ("total_copies", "Total Copies"),
    ("available_copies", "Available Copies"), ("issued_copies", "Issued Copies"),
    ("students", "Registered Students"), ("currently_issued", "Currently Issued"),
    ("overdue", "Overdue Books"), ("waiting_reservations", "Waiting Reservations"),
]


class DashboardFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        page_header(self, "Dashboard", "Overview of the library").pack(anchor="w", pady=(0, 10))

        grid = ttk.Frame(self)
        grid.pack(fill="x")
        self.values = {}
        for i, (key, label) in enumerate(CARDS):
            card = tk.Frame(grid, bg="white", padx=14, pady=10, highlightthickness=1,
                            highlightbackground="#d5dae6")
            card.grid(row=i // 4, column=i % 4, padx=6, pady=6, sticky="nsew")
            grid.columnconfigure(i % 4, weight=1)
            value = tk.Label(card, text="0", bg="white", fg=ACCENT, font=("Segoe UI", 22, "bold"))
            value.pack(anchor="w")
            tk.Label(card, text=label, bg="white", fg=MUTED).pack(anchor="w")
            self.values[key] = value

        lower = ttk.Frame(self)
        lower.pack(fill="both", expand=True, pady=(10, 0))
        lower.columnconfigure(0, weight=1)
        lower.columnconfigure(1, weight=2)
        lower.rowconfigure(1, weight=1)

        ttk.Label(lower, text="Recent activity this session (Stack - newest on top)").grid(row=0, column=0, sticky="w")
        self.recent = tk.Listbox(lower, font=("Segoe UI", 10), activestyle="none", height=10)
        self.recent.grid(row=1, column=0, sticky="nsew", padx=(0, 8))

        ttk.Label(lower, text="Activity log (saved in database)").grid(row=0, column=1, sticky="w")
        self.log = DataTable(lower, [("created_at", "Time", 140), ("action", "Action", 130),
                                     ("details", "Details", 380)], height=10)
        self.log.grid(row=1, column=1, sticky="nsew")

    def refresh(self):
        summary = self.svc.reports.summary()
        for key, label in self.values.items():
            label.config(text=str(summary[key]))
        self.recent.delete(0, "end")
        items = self.svc.issues.recent_activity()
        for text in items or ["(no actions yet in this session)"]:
            self.recent.insert("end", text)
        self.log.set_rows(self.svc.issues.activity_log(30))
