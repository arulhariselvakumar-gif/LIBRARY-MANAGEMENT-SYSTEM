"""Login screen."""
import tkinter as tk
from tkinter import ttk

from auth import login, AuthError
from ui.widgets import ACCENT, FONT_BOLD


class LoginFrame(ttk.Frame):
    def __init__(self, parent, svc, on_success):
        super().__init__(parent)
        self.svc, self.on_success = svc, on_success

        card = tk.Frame(self, bg="white", padx=40, pady=30, highlightthickness=1,
                        highlightbackground="#d5dae6")
        card.place(relx=0.5, rely=0.47, anchor="center")
        tk.Label(card, text="Library Management System", bg="white", fg=ACCENT,
                 font=("Segoe UI", 20, "bold")).pack()
        tk.Label(card, text="DSA Minor Project - Admin Login", bg="white", fg="#6b7385").pack(pady=(0, 18))

        tk.Label(card, text="Username", bg="white", font=FONT_BOLD).pack(anchor="w")
        self.username = ttk.Entry(card, width=34)
        self.username.pack(pady=(2, 10))
        tk.Label(card, text="Password", bg="white", font=FONT_BOLD).pack(anchor="w")
        self.password = ttk.Entry(card, width=34, show="*")
        self.password.pack(pady=(2, 10))

        self.error = tk.Label(card, text="", bg="white", fg="#d64545")
        self.error.pack()
        ttk.Button(card, text="Login", style="Accent.TButton", command=self.do_login).pack(fill="x", pady=(8, 0))

        self.username.bind("<Return>", lambda _e: self.password.focus_set())
        self.password.bind("<Return>", lambda _e: self.do_login())
        self.username.focus_set()

    def do_login(self):
        try:
            user = login(self.username.get(), self.password.get(), self.svc.db_path)
        except AuthError as err:
            self.error.config(text=str(err))
            self.password.delete(0, "end")
            return
        self.on_success(user)
