"""Reports screen with CSV export."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from ui.widgets import DataTable, page_header

REPORTS = {
    "All books": ("book_id", "title", "author", "category", "isbn", "quantity", "available_copies"),
    "Currently issued books": ("issue_id", "title", "student_name", "reg_no", "issue_date", "due_date"),
    "Overdue books": ("issue_id", "title", "student_name", "reg_no", "due_date", "overdue_days", "fine"),
    "Registered students": ("student_id", "reg_no", "name", "department", "email", "phone"),
    "Reservation waiting list": ("title", "position", "student_name", "reserved_on"),
}
HEADINGS = {"book_id": "Book ID", "title": "Title", "author": "Author", "category": "Category",
            "isbn": "ISBN", "quantity": "Quantity", "available_copies": "Available",
            "issue_id": "Issue ID", "student_name": "Student", "reg_no": "Register No.",
            "issue_date": "Issued", "due_date": "Due", "overdue_days": "Days late", "fine": "Fine",
            "student_id": "Student ID", "name": "Name", "department": "Department", "email": "Email",
            "phone": "Phone", "position": "Position", "reserved_on": "Reserved on"}


class ReportsFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        self.current_rows, self.current_cols = [], ()
        page_header(self, "Reports", "View a report and export it to CSV").pack(anchor="w")

        self.summary = tk.Label(self, text="", anchor="w", justify="left", bg="white", padx=12, pady=8,
                                font=("Segoe UI", 10), highlightthickness=1, highlightbackground="#d5dae6")
        self.summary.pack(fill="x", pady=8)

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(0, 6))
        self.report_box = ttk.Combobox(bar, values=list(REPORTS), state="readonly", width=28)
        self.report_box.set("All books")
        self.report_box.pack(side="left", padx=(0, 6))
        ttk.Button(bar, text="Show Report", style="Accent.TButton", command=self.show_report).pack(side="left")
        ttk.Button(bar, text="Export to CSV", command=self.export).pack(side="left", padx=6)

        self.holder = ttk.Frame(self)
        self.holder.pack(fill="both", expand=True)
        self.table = None

    def refresh(self):
        s = self.svc.reports.summary()
        self.summary.config(text=(
            f"Total book titles: {s['total_titles']}    Total copies: {s['total_copies']}    "
            f"Available: {s['available_copies']}    Issued: {s['issued_copies']}\n"
            f"Registered students: {s['students']}    Currently issued: {s['currently_issued']}    "
            f"Overdue: {s['overdue']}    Waiting reservations: {s['waiting_reservations']}"))
        self.show_report()

    def get_rows(self, name):
        if name == "All books":
            return self.svc.books.get_all_books()
        if name == "Currently issued books":
            return self.svc.issues.get_active_issues()
        if name == "Overdue books":
            return self.svc.issues.get_overdue()
        if name == "Registered students":
            return self.svc.students.get_all_students()
        return self.svc.issues.get_all_waiting()

    def show_report(self):
        name = self.report_box.get()
        self.current_cols = REPORTS[name]
        self.current_rows = self.get_rows(name)
        if self.table is not None:
            self.table.destroy()
        self.table = DataTable(self.holder, [(c, HEADINGS[c], 120) for c in self.current_cols], height=12)
        self.table.pack(fill="both", expand=True)
        self.table.set_rows(self.current_rows)

    def export(self):
        if not self.current_rows:
            messagebox.showinfo("Export", "This report is empty, so there is nothing to export.")
            return
        name = self.report_box.get().lower().replace(" ", "_")
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"{name}.csv",
                                            filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        try:
            count = self.svc.reports.export_csv(path, self.current_cols, self.current_rows)
        except OSError as err:
            messagebox.showerror("Export failed", str(err))
            return
        messagebox.showinfo("Export", f"{count} row(s) saved to:\n{path}")
