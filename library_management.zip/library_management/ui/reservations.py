"""Reservation screen: waiting list (Queue) for books with no copies available."""
import tkinter as tk
from tkinter import ttk, messagebox

from ui.widgets import DataTable, page_header, make_choices, parse_choice_id


class ReservationsFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        page_header(self, "Reservation Queue",
                    "First reserved, first served. A returned copy goes to the front of the queue.").pack(anchor="w")

        form = ttk.LabelFrame(self, text="Reserve a book (only when no copies are available)", padding=10)
        form.pack(fill="x", pady=8)
        ttk.Label(form, text="Book").grid(row=0, column=0, sticky="w", padx=4)
        ttk.Label(form, text="Student").grid(row=0, column=1, sticky="w", padx=4)
        self.book_box = ttk.Combobox(form, width=42, state="readonly")
        self.student_box = ttk.Combobox(form, width=34, state="readonly")
        self.book_box.grid(row=1, column=0, padx=4, pady=4)
        self.student_box.grid(row=1, column=1, padx=4, pady=4)
        ttk.Button(form, text="Add to Queue", style="Accent.TButton", command=self.reserve).grid(row=1, column=2, padx=8)

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(4, 4))
        ttk.Label(bar, text="Waiting list (position 1 = next to get the book)").pack(side="left")
        ttk.Button(bar, text="Cancel Selected", style="Danger.TButton", command=self.cancel).pack(side="right")

        self.table = DataTable(self, [("book_id", "Book ID", 70), ("title", "Book", 260),
                                      ("position", "Position", 70), ("student_name", "Student", 170),
                                      ("reserved_on", "Reserved on", 100)], height=13)
        self.table.pack(fill="both", expand=True)
        self.info = ttk.Label(self, text="", style="Muted.TLabel")
        self.info.pack(anchor="w", pady=4)

    def refresh(self):
        books = [b for b in self.svc.books.get_all_books() if b["available_copies"] == 0]
        self.book_box["values"] = make_choices(books, "book_id", lambda b: b["title"])
        self.student_box["values"] = make_choices(
            self.svc.students.get_all_students(), "student_id", lambda s: f"{s['name']} ({s['reg_no']})")
        self.book_box.set("")
        self.student_box.set("")
        rows = self.svc.issues.get_all_waiting()
        self.table.set_rows(rows)
        self.info.config(text="" if books else "All books currently have copies available, so nothing needs reserving.")

    def reserve(self):
        try:
            book_id = parse_choice_id(self.book_box.get())
            student_id = parse_choice_id(self.student_box.get())
            self.svc.issues.reserve_book(book_id, student_id)
        except ValueError as err:
            messagebox.showerror("Cannot reserve", str(err))
            return
        messagebox.showinfo("Success", "Student added to the waiting list.")
        self.refresh()

    def cancel(self):
        row = self.table.selected_row()
        if not row:
            messagebox.showwarning("Select a reservation", "Click a reservation in the table first.")
            return
        if not messagebox.askyesno("Confirm", "Cancel the selected reservation?"):
            return
        try:
            self.svc.issues.cancel_reservation(row["reservation_id"])
        except ValueError as err:
            messagebox.showerror("Cannot cancel", str(err))
            return
        self.refresh()
