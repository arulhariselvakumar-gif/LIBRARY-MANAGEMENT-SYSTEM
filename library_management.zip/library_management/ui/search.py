"""Search and sorting screen. Shows which algorithm ran and its complexity."""
import tkinter as tk
from tkinter import ttk, messagebox

from search_sort import SEARCH_FIELDS, SORT_FIELDS
from ui.widgets import DataTable, page_header


class SearchFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        page_header(self, "Search & Sort", "Searching and sorting use the algorithms written in the dsa/ folder").pack(anchor="w")

        search = ttk.LabelFrame(self, text="Search books", padding=10)
        search.pack(fill="x", pady=6)
        self.field = ttk.Combobox(search, values=SEARCH_FIELDS, state="readonly", width=12)
        self.field.set("Title")
        self.field.pack(side="left", padx=4)
        self.query = ttk.Entry(search, width=34)
        self.query.pack(side="left", padx=4)
        self.query.bind("<Return>", lambda _e: self.do_search())
        ttk.Button(search, text="Search", style="Accent.TButton", command=self.do_search).pack(side="left", padx=4)

        sort = ttk.LabelFrame(self, text="Sort books", padding=10)
        sort.pack(fill="x", pady=6)
        self.sort_field = ttk.Combobox(sort, values=list(SORT_FIELDS), state="readonly", width=18)
        self.sort_field.set("Title")
        self.sort_field.pack(side="left", padx=4)
        self.algo = ttk.Combobox(sort, values=["Merge Sort", "Bubble Sort"], state="readonly", width=12)
        self.algo.set("Merge Sort")
        self.algo.pack(side="left", padx=4)
        self.order = ttk.Combobox(sort, values=["Ascending", "Descending"], state="readonly", width=12)
        self.order.set("Ascending")
        self.order.pack(side="left", padx=4)
        ttk.Button(sort, text="Sort", style="Accent.TButton", command=self.do_sort).pack(side="left", padx=4)
        ttk.Button(sort, text="Show All", command=self.refresh).pack(side="left", padx=4)

        self.info = tk.Label(self, text="", anchor="w", justify="left", bg="#e8f0fe", fg="#1d2433",
                             padx=10, pady=6, font=("Segoe UI", 10))
        self.info.pack(fill="x", pady=6)

        self.table = DataTable(self, [("book_id", "ID", 50), ("title", "Title", 280), ("author", "Author", 170),
                                      ("category", "Category", 150), ("quantity", "Qty", 60),
                                      ("available_copies", "Available", 80)], height=12)
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        self.table.set_rows(self.svc.books.get_all_books())
        self.info.config(text="Showing all books in database order.")

    def show_result(self, result):
        self.table.set_rows(result["results"])
        lines = [f"Algorithm: {result['algorithm']}",
                 f"Complexity: {result['complexity']}"]
        if result["comparisons"] is not None:
            lines.append(f"Comparisons made: {result['comparisons']}")
        if result["message"]:
            lines.append(result["message"])
        lines.append(f"Records shown: {len(result['results'])}")
        self.info.config(text="\n".join(lines))

    def do_search(self):
        try:
            result = self.svc.search.search(self.field.get(), self.query.get())
        except ValueError as err:
            messagebox.showerror("Search", str(err))
            return
        self.show_result(result)

    def do_sort(self):
        try:
            result = self.svc.search.sort_books(self.sort_field.get(), self.algo.get(),
                                                self.order.get() == "Descending")
        except ValueError as err:
            messagebox.showerror("Sort", str(err))
            return
        self.show_result(result)
