"""Student management screen."""
import tkinter as tk
from tkinter import ttk, messagebox

from ui.widgets import DataTable, page_header

FIELDS = [("reg_no", "Register No."), ("name", "Name"), ("department", "Department"),
          ("email", "Email"), ("phone", "Phone")]


class StudentsFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        self.selected_id = None
        page_header(self, "Student Management", "Register, search, update and delete students").pack(anchor="w")

        form = ttk.LabelFrame(self, text="Student details", padding=10)
        form.pack(fill="x", pady=8)
        self.entries = {}
        for i, (key, label) in enumerate(FIELDS):
            ttk.Label(form, text=label).grid(row=0, column=i, sticky="w", padx=4)
            entry = ttk.Entry(form, width=20)
            entry.grid(row=1, column=i, padx=4, pady=(0, 4), sticky="w")
            self.entries[key] = entry
        buttons = ttk.Frame(form)
        buttons.grid(row=2, column=0, columnspan=len(FIELDS), sticky="w", pady=(6, 0))
        ttk.Button(buttons, text="Register Student", style="Accent.TButton", command=self.add).pack(side="left", padx=4)
        ttk.Button(buttons, text="Update Selected", command=self.update).pack(side="left", padx=4)
        ttk.Button(buttons, text="Delete Selected", style="Danger.TButton", command=self.delete).pack(side="left", padx=4)
        ttk.Button(buttons, text="Clear", command=self.clear_form).pack(side="left", padx=4)

        search = ttk.Frame(self)
        search.pack(fill="x", pady=(0, 6))
        ttk.Label(search, text="Search by student ID, name or register no.:").pack(side="left")
        self.search_var = tk.StringVar()
        entry = ttk.Entry(search, textvariable=self.search_var, width=28)
        entry.pack(side="left", padx=6)
        entry.bind("<Return>", lambda _e: self.search())
        ttk.Button(search, text="Search", command=self.search).pack(side="left")
        ttk.Button(search, text="Show All", command=self.refresh).pack(side="left", padx=4)
        self.info = ttk.Label(search, text="", style="Muted.TLabel")
        self.info.pack(side="left", padx=10)

        self.table = DataTable(self, [("student_id", "ID", 50), ("reg_no", "Register No.", 110),
                                      ("name", "Name", 180), ("department", "Department", 170),
                                      ("email", "Email", 190), ("phone", "Phone", 110)], height=14)
        self.table.pack(fill="both", expand=True)
        self.table.on_select(self.on_row_selected)

    def refresh(self):
        self.search_var.set("")
        self.table.set_rows(self.svc.students.get_all_students())
        self.info.config(text="")
        self.selected_id = None

    def search(self):
        rows = self.svc.students.search_students(self.search_var.get())
        self.table.set_rows(rows)
        self.info.config(text=f"{len(rows)} student(s) found" if rows else "No students found.")

    def values(self):
        return [self.entries[k].get() for k, _ in FIELDS]

    def clear_form(self):
        for entry in self.entries.values():
            entry.delete(0, "end")
        self.selected_id = None

    def on_row_selected(self):
        row = self.table.selected_row()
        if not row:
            return
        self.selected_id = row["student_id"]
        for key, _ in FIELDS:
            self.entries[key].delete(0, "end")
            self.entries[key].insert(0, str(row[key] or ""))

    def add(self):
        try:
            new_id = self.svc.students.add_student(*self.values())
        except ValueError as err:
            messagebox.showerror("Cannot register student", str(err))
            return
        messagebox.showinfo("Success", f"Student registered with ID {new_id}.")
        self.clear_form()
        self.refresh()

    def update(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a student", "Click a student in the table first.")
            return
        try:
            self.svc.students.update_student(self.selected_id, *self.values())
        except ValueError as err:
            messagebox.showerror("Cannot update student", str(err))
            return
        messagebox.showinfo("Success", "Student updated.")
        self.clear_form()
        self.refresh()

    def delete(self):
        if self.selected_id is None:
            messagebox.showwarning("Select a student", "Click a student in the table first.")
            return
        if not messagebox.askyesno("Confirm delete", "Delete the selected student permanently?"):
            return
        try:
            self.svc.students.delete_student(self.selected_id)
        except ValueError as err:
            messagebox.showerror("Cannot delete student", str(err))
            return
        messagebox.showinfo("Success", "Student deleted.")
        self.clear_form()
        self.refresh()
