"""Issue / return screen: issue books, return books, see overdue, undo the last action (Stack)."""
import tkinter as tk
from tkinter import ttk, messagebox

from ui.widgets import DataTable, page_header, make_choices, parse_choice_id


class TransactionsFrame(ttk.Frame):
    def __init__(self, parent, svc):
        super().__init__(parent, padding=16)
        self.svc = svc
        page_header(self, "Issue / Return", "Fine rule: loan period and fine per day are set in main.py").pack(anchor="w")

        form = ttk.LabelFrame(self, text="Issue a book", padding=10)
        form.pack(fill="x", pady=8)
        ttk.Label(form, text="Book").grid(row=0, column=0, sticky="w", padx=4)
        ttk.Label(form, text="Student").grid(row=0, column=1, sticky="w", padx=4)
        self.book_box = ttk.Combobox(form, width=42, state="readonly")
        self.student_box = ttk.Combobox(form, width=34, state="readonly")
        self.book_box.grid(row=1, column=0, padx=4, pady=4)
        self.student_box.grid(row=1, column=1, padx=4, pady=4)
        ttk.Button(form, text="Issue Book", style="Accent.TButton", command=self.issue).grid(row=1, column=2, padx=8)

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=(4, 4))
        ttk.Label(bar, text="Currently issued books (red = overdue)").pack(side="left")
        ttk.Button(bar, text="Undo Last Action", command=self.undo).pack(side="right", padx=4)
        ttk.Button(bar, text="Return Selected Book", style="Accent.TButton", command=self.return_selected).pack(side="right", padx=4)
        self.only_overdue = tk.BooleanVar(value=False)
        ttk.Checkbutton(bar, text="Show only overdue", variable=self.only_overdue,
                        command=self.refresh_table).pack(side="right", padx=10)

        self.table = DataTable(self, [
            ("issue_id", "Issue ID", 70), ("title", "Book", 240), ("student_name", "Student", 150),
            ("issue_date", "Issued", 90), ("due_date", "Due", 90),
            ("overdue_days", "Days late", 80), ("fine", "Fine", 70)], height=13)
        self.table.pack(fill="both", expand=True)

    def refresh(self):
        self.book_box["values"] = make_choices(
            self.svc.books.get_all_books(), "book_id",
            lambda b: f"{b['title']} ({b['available_copies']} available)")
        self.student_box["values"] = make_choices(
            self.svc.students.get_all_students(), "student_id", lambda s: f"{s['name']} ({s['reg_no']})")
        self.book_box.set("")
        self.student_box.set("")
        self.refresh_table()

    def refresh_table(self):
        rows = self.svc.issues.get_overdue() if self.only_overdue.get() else self.svc.issues.get_active_issues()
        self.table.set_rows(rows, tag_func=lambda r: "overdue" if r["overdue_days"] > 0 else None)

    def issue(self):
        try:
            book_id = parse_choice_id(self.book_box.get())
            student_id = parse_choice_id(self.student_box.get())
            self.svc.issues.issue_book(book_id, student_id)
        except ValueError as err:
            messagebox.showerror("Cannot issue book", str(err))
            return
        messagebox.showinfo("Success", "Book issued successfully.")
        self.refresh()

    def return_selected(self):
        row = self.table.selected_row()
        if not row:
            messagebox.showwarning("Select a record", "Click an issued book in the table first.")
            return
        try:
            result = self.svc.issues.return_book(row["issue_id"])
        except ValueError as err:
            messagebox.showerror("Cannot return book", str(err))
            return
        message = "Book returned successfully."
        if result["overdue_days"]:
            message += f"\nLate by {result['overdue_days']} day(s). Fine to collect: {result['fine']}"
        if result["auto_issued_to"]:
            message += f"\nThe copy was issued to {result['auto_issued_to']} from the reservation queue."
        messagebox.showinfo("Success", message)
        self.refresh()

    def undo(self):
        try:
            message = self.svc.issues.undo_last()
        except ValueError as err:
            messagebox.showwarning("Cannot undo", str(err))
            return
        messagebox.showinfo("Undo", message)
        self.refresh()
