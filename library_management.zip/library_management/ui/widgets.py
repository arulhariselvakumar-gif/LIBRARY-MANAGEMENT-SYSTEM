"""Small shared helpers for all screens: colours, styles, table, dropdown helpers."""
import tkinter as tk
from tkinter import ttk

BG = "#f4f6fa"
SIDEBAR = "#1f2a44"
SIDEBAR_HOVER = "#2d3b5f"
ACCENT = "#2f6fed"
TEXT = "#1d2433"
MUTED = "#6b7385"
FONT = ("Segoe UI", 10)
FONT_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 18, "bold")


def setup_style(root):
    root.configure(bg=BG)
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", font=FONT, background=BG, foreground=TEXT)
    style.configure("TFrame", background=BG)
    style.configure("TLabel", background=BG, foreground=TEXT)
    style.configure("Card.TFrame", background="white")
    style.configure("Card.TLabel", background="white")
    style.configure("TButton", padding=(10, 5))
    style.configure("Accent.TButton", background=ACCENT, foreground="white", padding=(12, 6),
                    font=FONT_BOLD)
    style.map("Accent.TButton", background=[("active", "#1f56c4")])
    style.configure("Danger.TButton", background="#d64545", foreground="white", padding=(10, 5))
    style.map("Danger.TButton", background=[("active", "#b83030")])
    style.configure("Treeview", rowheight=26, font=FONT, background="white", fieldbackground="white")
    style.configure("Treeview.Heading", font=FONT_BOLD, background="#e4e8f0", padding=4)
    style.map("Treeview", background=[("selected", ACCENT)], foreground=[("selected", "white")])
    style.configure("Title.TLabel", font=FONT_TITLE, background=BG)
    style.configure("Muted.TLabel", foreground=MUTED, background=BG)


class DataTable(ttk.Frame):
    """A Treeview with scrollbars. columns = [(key, heading, width), ...]."""

    def __init__(self, parent, columns, height=10):
        super().__init__(parent)
        self.columns = columns
        self._rows = []
        self.tree = ttk.Treeview(self, columns=[c[0] for c in columns], show="headings",
                                 height=height, selectmode="browse")
        for key, heading, width in columns:
            self.tree.heading(key, text=heading)
            self.tree.column(key, width=width, anchor="w")
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(self, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.tree.tag_configure("overdue", background="#fde2e2")
        self.tree.tag_configure("low", background="#fff4d6")

    def set_rows(self, rows, tag_func=None):
        self._rows = list(rows)
        self.tree.delete(*self.tree.get_children())
        for index, row in enumerate(self._rows):
            values = [row.get(key, "") for key, _, _ in self.columns]
            values = ["" if v is None else v for v in values]
            tags = (tag_func(row),) if tag_func and tag_func(row) else ()
            self.tree.insert("", "end", iid=str(index), values=values, tags=tags)

    def selected_row(self):
        selection = self.tree.selection()
        return self._rows[int(selection[0])] if selection else None

    def on_select(self, callback):
        self.tree.bind("<<TreeviewSelect>>", lambda _e: callback())


def page_header(parent, title, subtitle=""):
    frame = ttk.Frame(parent)
    ttk.Label(frame, text=title, style="Title.TLabel").pack(anchor="w")
    if subtitle:
        ttk.Label(frame, text=subtitle, style="Muted.TLabel").pack(anchor="w")
    return frame


def make_choices(rows, id_key, label_func):
    """Build dropdown text like '3 - Python Basics'."""
    return [f"{row[id_key]} - {label_func(row)}" for row in rows]


def parse_choice_id(text):
    """Get the number back from '3 - Python Basics'. Raises ValueError if nothing chosen."""
    text = (text or "").strip()
    if not text:
        raise ValueError("Please select an item from the list.")
    return int(text.split(" - ")[0])
